"""Synthetic DS-A1 display/state checks; no native runtime or business input."""
import importlib.util
import json
import subprocess
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
SOURCE = ROOT / 'scripts/agent-run-result.py'
spec = importlib.util.spec_from_file_location('result_adapter', SOURCE)
adapter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(adapter)

def assistant(text, **fields):
    return {'type':'assistant','message':{'content':[{'type':'text','text':text}]},**fields}

cases = []
for name, value in [('empty',''),('whitespace','  '),('null',None),('number',42),('list',[])]:
    cases.append((name+'-partial', value, 'partial', None))
cases += [('missing-partial', None, 'partial', 'missing')]
for name, value in [('empty',''),('whitespace','  ')]:
    cases += [(name+'-no-root',value,'none',None),(name+'-nested',value,'nested',None)]
for reason in ('refusal','max_tokens','content_filter'):
    cases.append((reason+'-nonempty','authoritative','partial',reason))
cases.append(('valid-nonempty','authoritative','partial',None))
records = []
for name, value, prior, reason in cases:
    case = HERE / name
    case.mkdir()
    events = [{'type':'system','subtype':'init'}]
    if prior == 'partial':
        events.append(assistant('partial root'))
    elif prior == 'nested':
        events += [
            {'type':'assistant','message':{'content':[{'type':'tool_use','id':'parent','name':'Bash','input':{}}]}},
            assistant('child text',parent_tool_use_id='parent'),
            {'type':'user','message':{'content':[{'type':'tool_result','tool_use_id':'parent','content':'output','is_error':False}]}}]
    terminal = {'type':'result','subtype':'success','is_error':False,'result':value}
    if reason == 'missing':
        terminal.pop('result')
    elif reason:
        terminal['stop_reason'] = reason
    events.append(terminal)
    output, stderr = case/'events.jsonl', case/'runtime.stderr'
    output.write_text(''.join(json.dumps(event)+'\n' for event in events))
    stderr.write_text('')
    args = SimpleNamespace(runtime='claude',provider='synthetic',output=str(output),stderr=str(stderr),
        exit_code=0,runner_exit_code=0,canary_file=None,canary_expected=None,artifact=[],last_message=None,wall_clock_seconds=None)
    collection = adapter.Collection(args)
    report = collection.collect()
    readable = isinstance(value,str) and bool(value.strip()) and reason != 'missing'
    displayed = value if readable else 'partial root' if prior == 'partial' else ''
    line = len(events) if readable else 2 if prior == 'partial' else None
    valid = name == 'valid-nonempty'
    argv = ['python3','-B',str(SOURCE),'--runtime','claude','--provider','synthetic',
        '--output',str(output),'--stderr',str(stderr),'--exit-code','0','--runner-exit-code','0']
    result = subprocess.run(argv,cwd=ROOT,capture_output=True,text=True)
    (case/'collector.stdout').write_text(result.stdout)
    (case/'collector.stderr').write_text(result.stderr)
    cli = json.loads(result.stdout)
    assertions = {
        'display': report['final_answer'] == displayed,
        'chars': report['final_answer_chars'] == len(displayed),
        'source_line': collection.final_line == line,
        'final_valid': collection.final_valid is readable,
        'terminal_valid': collection.terminal_valid is valid,
        'terminal': report['terminal'] == ('success' if valid else 'failed'),
        'agent_status': report['agent_status'] == ('completed' if valid else 'failed'),
        'validation': report['validation_status'] == ('passed' if valid else 'rejected'),
        'runner_exit': report['runner_exit_code'] == (0 if valid else 1),
        'not_assessed': report['result_status'] == 'not_assessed',
        'cli_matches_direct': cli == report,
        'cli_exit': result.returncode == (0 if valid else 1),
    }
    record = {'case':name,'argv':argv,'cwd':str(ROOT),'actual_exit':result.returncode,
        'final_line':collection.final_line,'final_valid':collection.final_valid,
        'terminal_valid':collection.terminal_valid,'assertions':assertions}
    records.append(record)
    (HERE/'synthetic-summary.json').write_text(json.dumps(records,indent=2)+'\n')
    assert all(assertions.values()), record
print(f'{len(records)} cases / {sum(len(r["assertions"]) for r in records)} assertions passed')
