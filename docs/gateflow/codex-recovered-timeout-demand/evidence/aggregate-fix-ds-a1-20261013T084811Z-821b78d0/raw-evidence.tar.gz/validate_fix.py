"""Record exact DS-A1 validation commands, outputs, exits and source hashes."""
import datetime
import hashlib
import json
import shlex
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
SOURCES = ['scripts/agent-run-result.py','tests/test_agent_run_results.py']

def hashes():
    return {name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in SOURCES}

tests = ['test_claude_result_owns_final_without_assistant_fallback',
    'test_claude_native_negative_and_malformed_completion_overrides_success',
    'test_claude_nested_ownership_and_scoped_tool_pairing',
    'test_recovered_diagnostics_keep_selected_checks_for_both_runtimes',
    'test_terminal_order_and_trailing_metadata_cannot_change_proof',
    'test_codex_latest_message_owns_final_and_prose_is_unassessed',
    'test_parsing_damage_and_validation_do_not_erase_observed_completion']
unit = ['python3','-B','-m','unittest','discover','-s','tests','-p','test_agent_run_results.py','-v']
syntax = "from pathlib import Path; files=['scripts/agent-run-result.py','tests/test_agent_run_results.py']; [compile(Path(p).read_bytes(),p,'exec') for p in files]; print('Python syntax OK: '+', '.join(files))"
commands = [
    ('affected-tests',unit + [arg for name in tests for arg in ('-k',name)]),
    ('synthetic',['python3','-B',str(HERE/'probe_display.py')]),
    ('full-affected-suite',unit),
    ('python-syntax',['python3','-B','-c',syntax]),
    ('runner-syntax',['zsh','-n','scripts/codex-agent-run','scripts/claude-agent-run']),
    ('diff-check',['git','diff','--check']),
]
records = []
for label, argv in commands:
    before = hashes()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv,cwd=ROOT,capture_output=True,text=True)
    (HERE/(label+'.stdout')).write_text(result.stdout)
    (HERE/(label+'.stderr')).write_text(result.stderr)
    after = hashes()
    record = {'label':label,'command':shlex.join(argv),'argv':argv,'cwd':str(ROOT),
        'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'actual_exit':result.returncode,'source_sha256_before':before,'source_sha256_after':after,
        'stdout_path':str(HERE/(label+'.stdout')),'stderr_path':str(HERE/(label+'.stderr'))}
    records.append(record)
    (HERE/'validation.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label+': exit '+str(result.returncode)+', source unchanged='+str(before==after),flush=True)
    if result.returncode or before != after:
        raise SystemExit(result.returncode or 1)
for name in SOURCES:
    (HERE/('after-'+Path(name).name)).write_bytes((ROOT/name).read_bytes())
(HERE/'source-diff.patch').write_text(subprocess.check_output(['git','diff','--',*SOURCES],cwd=ROOT,text=True))
(HERE/'after.json').write_text(json.dumps({'source_sha256':hashes(),'python_version':sys.version,
    'branch':subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip(),
    'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()},indent=2)+'\n')
