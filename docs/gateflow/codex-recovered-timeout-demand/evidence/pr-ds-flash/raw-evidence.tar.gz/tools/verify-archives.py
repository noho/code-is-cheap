#!/usr/bin/env python3
"""Verify raw-evidence.tar.gz archives at the exact PR head OID.

Sources of truth:
- archive bytes: `git show <head>:<path>` (exact Git object at head)
- per-file hashes + archive hash: raw-evidence-index.json, also from exact head
- expected archive hashes: artifact-packaging.md at head (constants below)
Additionally compares against locally-present extracted raw files (working copy).
No extraction to disk: tar members are read in memory.
Usage: python3 -I verify-archives.py <repo> <head_oid>
"""
import hashlib, io, json, os, subprocess, sys, tarfile

repo, head = sys.argv[1], sys.argv[2]
BASE = "docs/gateflow/codex-recovered-timeout-demand/evidence"
EXPECTED = {
    "aggregate-ds-flash": ("e423438fde1b1b5e1a125a74301c75b3a2d2e88ccb43acf97da38ecfc1b96979", 7),
    "aggregate-rereview-ds-flash": ("9414cf27493471355617b8db0862293e60774294e38bbc37f4ed3c0de2dcba4b", 16),
    "controller-native": ("9a148c99b0e1729c1d14c23e2c50188e24f8dcf08a7f84200a4e45502d55de9e", 5),
    "controller-native-fixed": ("dde8fe203557c99b5bd84b934649a3717354b4f13f0c8ec2e0943dcec36c6c35", 5),
    "code-ds-flash": ("433a8b57f1fa052ecddb5fd48f6bdc0d29217c53d7b41228e6024ec4eaa16bd7", 79),
    "aggregate-fix-ds-a1-20261013T084811Z-821b78d0": ("325ca65b98e485c5ac0229781b14119dff2bfad0aec783eaf0e09354e12cbc5e", 88),
    "s1-implementation-20261013": ("b37ca7751d9567154d37a23a9f3c1a0f307368169ddb3745bcb9b5f5a7e6a278", 58),
}

def sha(b): return hashlib.sha256(b).hexdigest()

def show(path):
    return subprocess.run(["git", "-C", repo, "show", f"{head}:{path}"],
                          capture_output=True, check=True).stdout

overall = True
for d, (exp_sha, exp_count) in EXPECTED.items():
    scope = f"{BASE}/{d}"
    line = [f"=== {d}"]
    try:
        raw = show(f"{scope}/raw-evidence.tar.gz")
        idx = json.loads(show(f"{scope}/raw-evidence-index.json"))
    except subprocess.CalledProcessError as e:
        print(f"=== {d}\n  FETCH_FAILED {e}"); overall = False; continue
    ok = True
    a_sha = sha(raw)
    if a_sha != exp_sha: ok = False; line.append(f"  ARCHIVE_SHA_MISMATCH artifact-packaging@{head}: {a_sha} != {exp_sha}")
    if idx.get("archive_sha256") != a_sha: ok = False; line.append(f"  INDEX_ARCHIVE_SHA_MISMATCH: index={idx.get('archive_sha256')} actual={a_sha}")
    if idx.get("archive") != f"{scope}/raw-evidence.tar.gz": ok = False; line.append(f"  INDEX_ARCHIVE_PATH_MISMATCH: {idx.get('archive')}")
    if idx.get("raw_files") != exp_count: ok = False; line.append(f"  RAW_FILES_EXPECTED_MISMATCH: index={idx.get('raw_files')} expected={exp_count}")
    tf = tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz")
    members = {}
    bad_member = []
    for m in tf.getmembers():
        name = m.name
        if name.startswith("./"): name = name[2:]
        if not m.isfile() or name.startswith("/") or ".." in name.split("/"):
            bad_member.append(name); continue
        if name in members:
            bad_member.append(name + " (duplicate)")
        members[name] = m
    if bad_member: ok = False; line.append(f"  UNSAFE_OR_NONREGULAR_MEMBERS: {bad_member}")
    keys = set(idx["files_sha256"])
    if set(members) != keys:
        ok = False
        line.append(f"  MEMBER_SET_MISMATCH only_in_archive={sorted(set(members)-keys)} only_in_index={sorted(keys-set(members))}")
    if len(members) != exp_count: ok = False; line.append(f"  MEMBER_COUNT {len(members)} != expected {exp_count}")
    # per-entry hash check + local extracted comparison
    entry_bad = []; local_match = 0; local_mismatch = []; local_missing = 0
    for name, m in sorted(members.items()):
        data = tf.extractfile(m).read()
        h = sha(data)
        if idx["files_sha256"].get(name) != h:
            entry_bad.append(f"{name}: archive={h} index={idx['files_sha256'].get(name)}")
        lp = os.path.join(repo, scope, name)
        if os.path.exists(lp):
            lh = sha(open(lp, "rb").read())
            if lh == h: local_match += 1
            else: local_mismatch.append(f"{name}: local={lh} archive={h}")
        else:
            local_missing += 1
    if entry_bad: ok = False; line.append(f"  ENTRY_HASH_MISMATCH x{len(entry_bad)}: {entry_bad[:5]}")
    if local_mismatch: ok = False; line.append(f"  LOCAL_RAW_MISMATCH x{len(local_mismatch)}: {local_mismatch[:5]}")
    status = "PASS" if ok else "FAIL"
    line.append(f"  status={status} archive_sha256={a_sha} raw_files={len(members)} indexed={len(keys)} "
                f"local_matches={local_match} local_missing={local_missing} local_mismatches={len(local_mismatch)}")
    print("\n".join(line))
    overall = overall and ok
print(f"RESULT={'PASS' if overall else 'FAIL'}")
sys.exit(0 if overall else 1)
