#!/usr/bin/env python3
"""Differential probe: retained-partial canary proof attribution, base vs head collector.
Case G : partial carries matching canary token, then empty-text assistant, no readable result.
Case G2: partial carries wrong token (mismatch attribution).
Usage: python3 -I probe-canary-attribution.py <outdir> <base_collector.py> <head_collector.py>
"""
import hashlib, json, os, subprocess, sys, tempfile

outdir, base_c, head_c = sys.argv[1], sys.argv[2], sys.argv[3]
TOKEN = "fresh-12345678"

def assistant(blocks): return {"type": "assistant", "message": {"content": blocks}}
def txt(t): return {"type": "text", "text": t}
INIT = {"type": "system", "subtype": "init", "model": "fixture"}

def run(collector, events, canary, expected):
    with tempfile.TemporaryDirectory() as td:
        out=os.path.join(td,"output.jsonl"); err=os.path.join(td,"stderr.log")
        with open(out,"w") as f:
            for e in events: f.write(json.dumps(e)+"\n")
        open(err,"w").close()
        r=subprocess.run(["python3","-B",collector,"--runtime","claude","--provider","synthetic",
                          "--output",out,"--stderr",err,"--exit-code","0","--runner-exit-code","0",
                          "--canary-file",canary,"--canary-expected",expected],
                         capture_output=True,text=True)
        rep=json.loads(r.stdout)
        return {"exit": r.returncode, "final_answer": rep["final_answer"], "canary_status": rep["canary_status"],
                "error_messages": [e["message"][:100] for e in rep["errors"]]}

summary={"base_collector_sha256": hashlib.sha256(open(base_c,'rb').read()).hexdigest(),
         "head_collector_sha256": hashlib.sha256(open(head_c,'rb').read()).hexdigest(), "cases": {}}
with tempfile.TemporaryDirectory() as td:
    canary=os.path.join(td,"canary.txt"); expected=os.path.join(td,"expected.txt")
    open(canary,"w").write(TOKEN); open(expected,"w").write(TOKEN)
    for name, token in (("G_match_token_in_partial", TOKEN), ("G2_wrong_token_in_partial", "wrong-token")):
        events=[INIT, assistant([txt(f"partial root\nCANARY={token}")]), assistant([txt("")])]
        b, h = run(base_c, events, canary, expected), run(head_c, events, canary, expected)
        summary["cases"][name]={"base": b, "head": h}
        print(f"{name}: base canary={b['canary_status']} final={b['final_answer']!r} | head canary={h['canary_status']} final={h['final_answer']!r}")
        print(f"   base errors={b['error_messages']}")
        print(f"   head errors={h['error_messages']}")
with open(os.path.join(outdir,"summary-canary.json"),"w") as f: json.dump(summary,f,indent=2,ensure_ascii=False)
print("RESULT_SAVED", os.path.join(outdir,"summary-canary.json"))
