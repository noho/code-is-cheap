#!/usr/bin/env python3
"""Independent completeness check for GitHub-vs-local PR diffs.

Normalizes ONLY the optional text after a hunk header's closing @@
(function/context label), while requiring exact numeric hunk ranges.
All other lines, file headers, index/metadata and context must match byte-exact.
Usage: python3 -I compare-diffs.py <github.diff> <local.diff>
"""
import re, sys
gh_path, local_path = sys.argv[1], sys.argv[2]
hunk_re = re.compile(rb'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@')
def norm(line):
    m = hunk_re.match(line)
    if m:
        s1 = int(m.group(1)); c1 = int(m.group(2)) if m.group(2) is not None else 1
        s2 = int(m.group(3)); c2 = int(m.group(4)) if m.group(4) is not None else 1
        return b'@@ -%d,%d +%d,%d @@' % (s1, c1, s2, c2), True
    return line, False
with open(gh_path,'rb') as f: gh = f.read().splitlines(keepends=True)
with open(local_path,'rb') as f: lo = f.read().splitlines(keepends=True)
print(f"github_lines={len(gh)} local_lines={len(lo)}")
gh_norm = [norm(l)[0] for l in gh]
lo_norm = [norm(l)[0] for l in lo]
def files(d): return [l for l in d if l.startswith(b'diff --git ')]
gfiles, lfiles = files(gh), files(lo)
print(f"github_files={len(gfiles)} local_files={len(lfiles)} file_lists_identical={gfiles==lfiles}")
raw_mismatch_idx = [i for i,(a,b) in enumerate(zip(gh,lo)) if a!=b]
print(f"raw_mismatch_lines={len(raw_mismatch_idx)}")
label_only = 0; other_mismatch = []
for i in raw_mismatch_idx:
    a, b = gh[i], lo[i]
    if hunk_re.match(a) and hunk_re.match(b) and gh_norm[i]==lo_norm[i]:
        label_only += 1
    else:
        other_mismatch.append(i)
print(f"label_only_diffs={label_only} other_mismatches={len(other_mismatch)}")
for i in other_mismatch[:10]:
    print(f"  line {i+1}: GH={gh[i][:120]!r} | LOCAL={lo[i][:120]!r}")
if len(gh) != len(lo):
    print("LENGTH_MISMATCH")
if gh_norm == lo_norm:
    print("NORMALIZED_COMPARE=PASS: all lines identical except optional hunk-header labels; numeric hunk ranges exact")
else:
    diffs = [ (i, a, b) for i,(a,b) in enumerate(zip(gh_norm, lo_norm)) if a!=b ]
    print(f"NORMALIZED_COMPARE=FAIL mismatches={len(diffs)}")
    for i,a,b in diffs[:5]:
        print(f"  line {i+1}: GH={a[:120]!r} | LOCAL={b[:120]!r}")
