#!/usr/bin/env python3
"""Differential probe: base(62c3b26) vs head(2f0db8f) collector display behavior.

Focus: root assistant frames whose text blocks join to an empty string while a
readable earlier root partial exists, on calls that end without a readable
authoritative result. Usage: python3 -I probe-empty-assistant-text.py <outdir> <base_collector.py> <head_collector.py>
"""
import hashlib, json, os, subprocess, sys, tempfile

outdir, base_c, head_c = sys.argv[1], sys.argv[2], sys.argv[3]

def assistant(blocks):
    return {"type": "assistant", "message": {"content": blocks}}
def txt(t):
    return {"type": "text", "text": t}
INIT = {"type": "system", "subtype": "init", "model": "fixture"}
PARTIAL = assistant([txt("partial root")])
EMPTY = assistant([txt("")])
def result(v):
    return {"type": "result", "subtype": "success", "is_error": False, "result": v}

CASES = {
    "A_no_result_after_empty_assistant": [INIT, PARTIAL, EMPTY],
    "B_nonstring_result_after_empty_assistant": [INIT, PARTIAL, EMPTY, result(42)],
    "C_control_valid_result_after_empty_assistant": [INIT, PARTIAL, EMPTY, result("done")],
    "D_control_tool_only_assistant": [INIT, PARTIAL, assistant([{"type": "tool_use", "id": "t", "name": "Bash", "input": {}}])],
    "E_control_mixed_empty_then_text": [INIT, PARTIAL, assistant([txt(""), txt("newer")])],
    "F_empty_text_with_tool_use": [INIT, PARTIAL, assistant([txt(""), {"type": "tool_use", "id": "t", "name": "Bash", "input": {}}])],
}

def run(collector, events):
    with tempfile.TemporaryDirectory() as td:
        out=os.path.join(td,"output.jsonl"); err=os.path.join(td,"stderr.log")
        with open(out,"w") as f:
            for e in events: f.write(json.dumps(e)+"\n")
        open(err,"w").close()
        r=subprocess.run(["python3","-B",collector,"--runtime","claude","--provider","synthetic",
                          "--output",out,"--stderr",err,"--exit-code","0","--runner-exit-code","0"],
                         capture_output=True,text=True)
        rep=json.loads(r.stdout)
        return {"exit": r.returncode, "final_answer": rep["final_answer"],
                "final_answer_chars": rep["final_answer_chars"], "agent_status": rep["agent_status"],
                "validation_status": rep["validation_status"], "terminal": rep["terminal"],
                "errors_top": [e["message"][:90] for e in rep["errors"][:3]]}

summary={"base_collector_sha256": hashlib.sha256(open(base_c,'rb').read()).hexdigest(),
         "head_collector_sha256": hashlib.sha256(open(head_c,'rb').read()).hexdigest(),
         "cases": {}}
for name, ev in CASES.items():
    b, h = run(base_c, ev), run(head_c, ev)
    summary["cases"][name]={"input_sha256": hashlib.sha256(json.dumps(ev,sort_keys=True).encode()).hexdigest(),
                            "base": b, "head": h,
                            "display_delta": (b["final_answer"], h["final_answer"]),
                            "outcome_fields_equal": all(b[k]==h[k] for k in ("exit","agent_status","validation_status","terminal","final_answer_chars") if k!="final_answer_chars") and b["final_answer_chars"]==h["final_answer_chars"] if b["final_answer"]==h["final_answer"] else None}
for name, c in summary["cases"].items():
    print(f"{name}: base_display={c['base']['final_answer']!r} head_display={c['head']['final_answer']!r} "
          f"base_exit={c['base']['exit']} head_exit={c['head']['exit']} "
          f"base_status={c['base']['validation_status']}/{c['base']['agent_status']} head_status={c['head']['validation_status']}/{c['head']['agent_status']}")
with open(os.path.join(outdir,"summary.json"),"w") as f: json.dump(summary,f,indent=2,ensure_ascii=False)
print("RESULT_SAVED", os.path.join(outdir,"summary.json"))
