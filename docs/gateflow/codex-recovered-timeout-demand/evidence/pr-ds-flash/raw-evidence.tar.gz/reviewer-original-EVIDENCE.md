# pr-ds-flash evidence index — PR 59 actual-PR review (ds-flash route, Claude runtime)

Gate/work unit: actual PR review / `codex-recovered-timeout-demand` / noho/code-is-cheap#59.
Reviewer route: ds-flash through Claude runtime. This directory is this reviewer's own durable
evidence; it does not modify sources, other reviewers' evidence, or controller state.

Identity (all requeries pinned, unchanged before diff / after diff / at close):

- Repository: `noho/code-is-cheap` (head repo identical; not a fork); PR 59
  `https://github.com/noho/code-is-cheap/pull/59`; title `fix(runners): decide call acceptance
  from native terminal state`; author `noho`; head branch `fix/codex-recovered-timeout-demand`
  (base `main`); draft `true`; state OPEN; mergeable MERGEABLE / CLEAN.
- head OID `2f0db8fb5fdfca02d90a69503b943aee348a81a0`, base OID
  `62c3b26adeb994e81043d7b1afbcd4c6eb8974ae`; local merge-base == base (base is ancestor).
- Diff snapshot only via exact compare endpoint
  `repos/noho/code-is-cheap/compare/62c3b26…...2f0db8f…` with
  `Accept: application/vnd.github.v3.diff` (`compare-url.txt`); no `gh pr diff`, no branch-name
  fallback. Snapshot `pr-59-compare.diff`, SHA-256
  `1be5b1e77a0403db3daac055a0a79bea83c307bc7fd0bf5362f190d11e096b00`, 135 files,
  9014+/1070− (identical to PR metadata `changedFiles/additions/deletions`).

Verification results:

- Completeness (`completeness-check.txt`, tool `tools/compare-diffs.py`, inputs
  `pr-59-compare.diff` + `local-compare.diff` SHA-256
  `2d1be12341e239c537dd207d4d6b97913c3b447bfcd865f5623252ad2e9f44dd`): NORMALIZED_COMPARE=PASS.
  11,049/11,049 lines; 135/135 file lists identical; exactly 10 raw mismatches, all optional
  hunk-header labels (GitHub `def …` vs local `class …`), numeric hunk ranges and all
  file/index/context lines byte-exact. Only that optional label was normalized.
- Five affected sources at head OID (`snapshot-head.hashes.txt`, read via `git show <headOID>:path`,
  snapshots under `snapshot-head/`; worktree byte-identical for all seven snapshotted files):
  collector `aa9b1a3eef7f048e6d8e8a06e06510da9178fcba9097270d422cf2eafc2dd7ff` == required,
  tests `6cda405c565c9ebc200885bd61c1d8fe7e480b3562330afacd63e9ac38be891b` == required,
  README.md `73141fd5…`, README.zh.md `61ff31d0…`, skills/sub-agents/SKILL.md `cb812b36…`.
  Unchanged runners `scripts/codex-agent-run` `45baef1f…`, `scripts/claude-agent-run`
  `4cdd1700…`; `tests/test_agent_sandbox_runtimes.py` no diff vs base.
- Hash lineage across checkpoints: base `8a0be0d0` → accepted slice edd3d7b `9b44ac33` →
  accepted deepreview 1bd8246 `aa9b1a3e` (DS-A1 fix) → packaging commits 85726b8/2f0db8f
  unchanged. Post-review packaging commits touch evidence/state only.
- Evidence archives from exact head (`archive-verification.txt`, tool
  `tools/verify-archives.py`): all 7 `raw-evidence.tar.gz` (aggregate-ds-flash,
  aggregate-rereview-ds-flash, controller-native, controller-native-fixed, code-ds-flash,
  aggregate-fix-ds-a1-…-821b78d0, s1-implementation-20261013) byte-exact vs
  artifact-packaging.md constants and head indexes; 258/258 member hashes == index == local
  extracted copies; no unsafe/nonregular/duplicate members; member sets == index keys.
- Controller current-version evidence (snapshots `snapshot-head/controller-evidence/`):
  controller-native-fixed summary.json exit 0, 2/2 ok, collector `aa9b1a3e`; original
  Developer replay fixed record 0/needs_review errors0/anomalies8, five notices retained,
  inputs before==after; Judge TLS replay fixed record 0/needs_review errors0/anomalies10,
  four TLS notices retained, unique terminal line61/final line60.
- CI/checks: `gh pr checks 59` → "no checks reported on the 'fix/codex-recovered-timeout-demand'
  branch" (exit 1); recorded as no remote CI, no pass claimed (`pr-checks.stdout/.stderr`).
- Fresh independent differential probes (base `8a0be0d0` vs head `aa9b1a3e`, synthetic inputs
  archived) in `probe-empty-assistant-text/`: found one low-severity display-retention delta
  (root assistant frame whose text blocks join to empty erases retained readable partial on
  calls without a readable result; consumes canary proof attribution of the partial). Controls
  (valid result / tool-only frame / empty-then-text frame) identical between versions.
  Details and finding write-up in `docs/reviews/pr-59-review-20261013-173833.md`.

Files:

- `pr-facts-before.json`, `pr-facts-after.json`, `pr-facts-close.json` — `gh pr view` facts
  before diff / requery after diff / requery at close (OIDs pinned throughout).
- `compare-url.txt`, `pr-59-compare-fetch.json`, `pr-59-compare.diff`, `pr-59-compare.diff.sha256`
  — exact compare request and snapshot.
- `local-compare.diff`, `local-compare.diff.sha256` — local `git diff <base>...<head>` for the
  same OIDs; `diff-collector.patch` — focused collector diff read in full.
- `completeness-check.txt`, `tools/compare-diffs.py` — controlled completeness comparison.
- `archive-verification.txt`, `tools/verify-archives.py` — exact-head archive/index/raw checks.
- `pr-checks.stdout`, `pr-checks.stderr` — CI/check record.
- `snapshot-head/` + `snapshot-head.hashes.txt` — `git show <headOID>:path` snapshots used for
  all deep-dive reading (five sources, both runners, controller-evidence records).
- `probe-empty-assistant-text/summary.json`, `summary-canary.json` and
  `tools/probe-empty-assistant-text.py`, `tools/probe-canary-attribution.py`,
  `tools/base-collector-62c3b26.py`, `tools/head-collector-2f0db8f.py` — independent
  base-vs-head differential probes supporting finding #1 (inputs are synthetic JSONL; no
  business data; no network).
- `evidence-inventory.sha256` — SHA-256 of every file above (excluding itself).

Boundaries honored: no source modification, no commit/push/PR write action, no delegation;
other reviewer routes' artifacts and opinions were not read; `portfolio-manager-v2` originals
were not opened (only controller-recorded sanitized metadata/hashes within this work unit's
evidence); no business Agent rerun; no claim of installed/live validation, fault reproduction,
or caller business acceptance. Installed sync/replays and the authorized dual-runtime
mimo-flash three-step live probes remain later controller delivery steps and are not claimed here.
