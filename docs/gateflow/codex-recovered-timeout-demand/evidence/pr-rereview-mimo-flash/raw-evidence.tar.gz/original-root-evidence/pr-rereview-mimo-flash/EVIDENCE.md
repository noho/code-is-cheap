# Evidence — PR59 DS-PR1 targeted actual-PR re-review (mimo-flash / Claude runtime)

Review artifact: `docs/reviews/pr-59-review-20261013-184446.md`
Target: PR #59, base `62c3b26adeb994e81043d7b1afbcd4c6eb8974ae`, head `aa7bcb747f41bba1ee1504005df5f938e8571aba` (stable at retrieval, after-diff requery and close requery).

| File | Purpose |
| --- | --- |
| `pr59-facts-20261013-181816.json` | PR facts (title/author/branches/OIDs/body/url/head repo) collected before diff |
| `compare-request-url.txt` | Exact compare API request URL used with `Accept: application/vnd.github.v3.diff` |
| `pr59-compare-62c3b26..aa7bcb7.diff` | Full raw API diff snapshot; SHA-256 `c19f9e4b9c927061b8fbb32c34b2ff9385afd5ec5f7712e2a7c3e10cf1decd6f` (1,046,238 bytes, 173 files) |
| `local-62c3b26-aa7bcb7.diff` | Local `git diff <base> <head>` at exact OIDs; SHA-256 `b71dd88e3a6f74c8fac0f5f161a7b6ed1c1c02f166c36077f012a019d2200c33` |
| `diff-identity.txt` | Identity check: identical file lists; only trailing hunk-label normalization; both canonical SHA-256 `a79e47f18320d9ea57108814df2f6293dd54425c834e53a97f36a9c7751c6812` |
| `pr-requery-after.json` / `close-requery.json` | OID requeries after diff retrieval and at close (identical, OPEN/draft) |
| `ci-checks.txt` | Actual CI reads: no checks reported; check-runs total 0; statuses 0; no `.github/` at head |
| `independent-new-method.{exit,stderr,stdout}` | Independent run of the single new regression method at head source: exit 0, Ran 1 OK |
| `source-hashes-after-run.txt` | Collector/tests SHA-256 after the independent run (unchanged `406ec869…`/`a65efef0…`) |
| `MANIFEST.sha256` | Hashes of all files in this directory |

No source files, PR state, or business inputs were modified or read. Synthetic fixtures only for the independent test run.
