"""Capture final source identity; observe controller bookkeeping without changing it."""
import ast
import datetime
import hashlib
import json
import subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[5]
p=Path(__file__).resolve().parent
before=json.loads((p/'before-manifest.json').read_text())
sources=list(before['sources'])
current={path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in before['unchanged_inputs']}
state='docs/gateflow/codex-recovered-timeout-demand/state.json'
changes={path:{'before':sha,'after':current[path]} for path,sha in before['unchanged_inputs'].items() if current[path]!=sha}
assert not (set(changes)-{state}),changes
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip()
assert (head,branch)==(before['head'],before['branch'])
for path in sources:
    assert (p/'final-source'/path).read_bytes()==(root/path).read_bytes()
diff=subprocess.check_output(['git','diff','--',*sources])
(p/'source-delta.patch').write_bytes(diff)
(p/'git-status-final.txt').write_text(subprocess.check_output(['git','status','--short'],text=True))
numstat=subprocess.check_output(['git','diff','--numstat','--',*sources],text=True)
(p/'source-numstat.txt').write_text(numstat)
manifest={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'branch':branch,
    'source_sha256':{path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in sources},
    'source_delta_sha256':hashlib.sha256(diff).hexdigest(),'numstat':numstat,
    'binding_input_sha256':{path:sha for path,sha in current.items() if path!=state},
    'binding_input_hashes_match_before':True,'concurrent_controller_owned_changes':changes,
    'state_ownership':'Observed only; no delegate writes or rollback. Controller reconciles its own bookkeeping.',
    'unittest_methods_before':sum(isinstance(n,ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse((p/'before-source/tests/test_agent_run_results.py').read_text()))),
    'unittest_methods_after':sum(isinstance(n,ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse((root/'tests/test_agent_run_results.py').read_text()))),
    'runs':{folder.name:json.loads((folder/'result.json').read_text()) for folder in sorted((p/'runs').iterdir()) if (folder/'result.json').exists()}}
assert manifest['unittest_methods_before']==56 and manifest['unittest_methods_after']==57
for name,run in manifest['runs'].items():
    assert run['source_hashes_before']==run['source_hashes_after'],name
    assert run['exit_code']==(1 if name=='red-regression' else 0),name
    if name not in ('red-regression','probe-before'):
        assert run['source_hashes_after']==manifest['source_sha256'],name
(p/'final-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='runs'},indent=2))
