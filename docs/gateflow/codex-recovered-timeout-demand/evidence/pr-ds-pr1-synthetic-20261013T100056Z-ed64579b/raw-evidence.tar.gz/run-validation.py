"""Record only synthetic/current-source validation; refuse overwriting prior runs."""
import datetime
import hashlib
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path

root=Path(__file__).resolve().parents[5]
evidence=Path(__file__).resolve().parent
label=sys.argv[1]
command=sys.argv[2:]
run=evidence/'runs'/label
run.mkdir(parents=True)
sources=['scripts/agent-run-result.py','tests/test_agent_run_results.py']
def source_hashes():
    return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sources}
for path in sources:
    target=run/'source'/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((root/path).read_bytes())
record={'command':command,'shell_display':shlex.join(command),'cwd':str(root),
        'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_hashes_before':source_hashes()}
start=time.monotonic()
try:
    result=subprocess.run(command,cwd=root,capture_output=True)
except Exception as exc:
    record.update(exception=repr(exc),duration_seconds=time.monotonic()-start)
    (run/'result.json').write_text(json.dumps(record,indent=2)+'\n')
    raise
(run/'stdout.log').write_bytes(result.stdout)
(run/'stderr.log').write_bytes(result.stderr)
record.update(exit_code=result.returncode,duration_seconds=time.monotonic()-start,
              completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              source_hashes_after=source_hashes())
(run/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'label':label,'exit_code':result.returncode,'seconds':record['duration_seconds'],
                  'record':str(run.relative_to(root)/'result.json')}))
print(result.stderr.decode('utf-8',errors='replace')[-1400:])
sys.exit(result.returncode)
