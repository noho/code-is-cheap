# DS-PR1 synthetic validation evidence

This uniquely named directory records the accepted DS-PR1 fix only. All protocol inputs are generated synthetic streams. Source applicability is explicit: before collector aa9b1a3e…, final collector 406ec869…, final test file a65efef0…. No archive/current-pass substitution, original replay or native/live pass is claimed.

- [before-manifest.json](before-manifest.json): initial source/input hashes, Python/platform, HEAD/branch; original sources under before-source/.
- [final-manifest.json](final-manifest.json): final exact source/patch hashes, 56→57 method count, binding equality and concurrent state drift; final sources under final-source/.
- [source-delta.patch](source-delta.patch): exact two-file worktree patch; source-numstat.txt and Git status snapshots identify the pre-existing controller work.
- [probe-before/snapshot.json](probe-before/snapshot.json) and [probe-after/snapshot.json](probe-after/snapshot.json): 62 complete input/report snapshots each, raw stdout/stderr, exact per-case argv/exits, internal final_line/final_valid/terminal_valid. The last scratch input file in each phase is not the full dataset; the snapshot embeds every exact input.
- [differential.json](differential.json): 57→0 contract-mismatch cases; completion/exit/proof/tool/result_status unchanged in all 62; five complete report controls equal with only fixture-directory paths normalized.
- [failed-final-capture-attempt/result.json](failed-final-capture-attempt/result.json): exact failed attempt and raw output saved after failure, exit 1 from concurrent controller-owned state hash drift. No rerun of the failed assertion and no state write.
- runs/<label>/result.json, stdout.log, stderr.log and source/: exact executed command/cwd/time/exits and before/after current-source hashes plus full source snapshot per run. Unit-test stderr contains the complete test list and actual failures/passes; stdout is retained even when empty.
- run-validation.py, probe.py, compare-probes.py and capture-final.py are newly written evidence helpers for synthetic/current-source recording only; no original replay helper is used.

## Commands and outcomes

Every row below is the exact command executed by run-validation.py. The invoking recorder command was `python3 -B <this-directory>/run-validation.py <label> <command>`; `<this-directory>` is `docs/gateflow/codex-recovered-timeout-demand/evidence/pr-ds-pr1-synthetic-20261013T100056Z-ed64579b`. The structured result.json preserves literal argv and exact cwd. Initial/final capture and differential construction used local Python scripts only; the failed initial heredoc is stored verbatim in its result.json.

| Label | Exit | Exact executed command |
| --- | --- | --- |
| affected-final | 0 | `python3 -B -m unittest discover -s tests -p test_agent_run_results.py -k test_claude_ -k test_terminal_order_and_trailing_metadata_cannot_change_proof -k test_recovered_diagnostics_keep_selected_checks_for_both_runtimes -k test_recovered_diagnostics_keep_native_and_postprocessing_failures -v` |
| capture-final | 0 | `python3 -B docs/gateflow/codex-recovered-timeout-demand/evidence/pr-ds-pr1-synthetic-20261013T100056Z-ed64579b/capture-final.py` |
| diff-check-final | 0 | `git diff --check` |
| differential-final | 0 | `python3 -B docs/gateflow/codex-recovered-timeout-demand/evidence/pr-ds-pr1-synthetic-20261013T100056Z-ed64579b/compare-probes.py` |
| full-suite-final | 0 | `python3 -B -m unittest discover -s tests -p test_agent_run_results.py -v` |
| probe-after | 0 | `python3 -B docs/gateflow/codex-recovered-timeout-demand/evidence/pr-ds-pr1-synthetic-20261013T100056Z-ed64579b/probe.py after` |
| probe-before | 0 | `python3 -B docs/gateflow/codex-recovered-timeout-demand/evidence/pr-ds-pr1-synthetic-20261013T100056Z-ed64579b/probe.py before` |
| red-regression | 1 | `python3 -B -m unittest discover -s tests -p test_agent_run_results.py -k test_claude_empty_assistant_text_retains_partial_and_proof_source -v` |
| syntax-final | 0 | `python3 -B -c 'from pathlib import Path; paths = ("scripts/agent-run-result.py", "tests/test_agent_run_results.py"); [compile(Path(path).read_bytes(), path, "exec") for path in paths]; print("Compiled both changed Python files without bytecode writes")'` |

The pre-fix regression exit 1 is expected bug evidence, with 57 failing subtests. probe-before exit 0 means the expected 57 mismatches were successfully reproduced, not that the before version met the contract. probe-after and differential-final establish zero mismatches. affected-final is 11 passed methods; full-suite-final is 57 passed methods, zero skips. The sole additional failed attempt is the state-equality capture above; the corrected capture records state separately and succeeds.

The full suite uses deterministic fake runtimes and the existing temporary installation test. It does not deploy to live. The known nested-blocked native kernel suite and both original replay versions remain controller-owned. State drift is observed only, with no rollback or source-check failure.

[pr-fix.md](../../pr-fix.md) is the handoff report. evidence-inventory.sha256 hashes every file in this evidence directory except the inventory itself; report.sha256 records the separate report hash.
