"""Persistent synthetic differential for accepted DS-PR1; no original input reads."""
import hashlib
import importlib.util
import json
import shlex
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

root=Path(__file__).resolve().parents[5]
evidence=Path(__file__).resolve().parent
phase=sys.argv[1]
assert phase in ('before','after')
run=evidence/('probe-'+phase)
run.mkdir()
collector=root/'scripts/agent-run-result.py'
spec=importlib.util.spec_from_file_location('collector_probe',collector)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def assistant(texts, parent=None, tool=None):
    blocks=[{'type':'text','text':t} for t in texts]
    if tool is not None:blocks.append({'type':'tool_use','id':tool,'name':'Bash','input':{}})
    return {'type':'assistant','message':{'content':blocks},'parent_tool_use_id':parent}
def tool_result(identity):
    return {'type':'user','message':{'content':[{'type':'tool_result','tool_use_id':identity,
        'content':'synthetic output','is_error':False}]}}
def result(**fields):
    return {'type':'result','subtype':'success','is_error':False,**fields}
init={'type':'system','subtype':'init','model':'fixture'}
cases=[]
invalids=[('missing-terminal',None),('missing-result',{}),
          *[(name,{'result':value}) for name,value in [('null',None),('number',42),('list',[]),('empty',''),('blank','  ')]]]
for token in ('fresh-12345678','wrong'):
    partial='partial root\nCANARY='+token
    for count in (1,3):
        for with_tool in (False,True):
            for name,fields in invalids:
                events=[init,assistant([partial]),assistant(['']*count,tool='t' if with_tool else None)]
                if with_tool:events.append(tool_result('t'))
                if fields is not None:events.append(result(**fields))
                cases.append({'name':f'{token}-{count}-{with_tool}-{name}','events':events,'selected_canary':True,
                    'expected':{'final_answer':partial,'final_answer_chars':len(partial),'final_line':2,
                        'agent_status':'failed','validation_status':'rejected','result_status':'not_assessed',
                        'exit_code':1,'runner_exit_code':1,'runtime_exit_code':0,
                        'terminal':None if fields is None else 'failed','tool_results':int(with_tool),
                        'canary_status':'match' if token=='fresh-12345678' else 'mismatch'}})
prior=assistant(['partial root'])
controls=[('valid-result',[assistant([''])],result(result='authoritative'),'authoritative',4,'passed','completed',0,0),
    ('negative-result',[assistant([''])],result(result='authoritative',stop_reason='content_filter'),
        'authoritative',4,'rejected','failed',1,0),
    ('tool-only',[assistant([],tool='t'),tool_result('t')],result(result=''),'partial root',2,'rejected','failed',1,1),
    ('mixed-root',[assistant(['','new root',''])],result(result=''),'new root',3,'rejected','failed',1,0),
    ('nested',[assistant([],tool='parent'),assistant([''],parent='parent'),assistant(['child text'],parent='parent'),
        tool_result('parent')],result(result=''),'partial root',2,'rejected','failed',1,1),
    ('whitespace-root',[assistant([' \t\n']),assistant([''])],result(result=''),' \t\n',3,'rejected','failed',1,0)]
for name,updates,terminal,display,line,validation,agent,exit_code,tools in controls:
    cases.append({'name':name,'events':[init,prior,*updates,terminal],'selected_canary':False,
        'expected':{'final_answer':display,'final_answer_chars':len(display),'final_line':line,
            'agent_status':agent,'validation_status':validation,'result_status':'not_assessed',
            'exit_code':exit_code,'runner_exit_code':exit_code,'runtime_exit_code':0,
            'terminal':'success' if agent=='completed' else 'failed','tool_results':tools,'canary_status':'not_run'}})
output=run/'output.jsonl'
stderr=run/'runtime.stderr'
stderr.write_text('')
canary=run/'canary.txt';canary.write_text('fresh-12345678')
expected=run/'expected.txt';expected.write_text('fresh-12345678')
records=[]
for case in cases:
    raw=''.join(json.dumps(e)+'\n' for e in case['events'])
    output.write_text(raw)
    argv=['python3','-B',str(collector),'--runtime','claude','--provider','synthetic',
          '--output',str(output),'--stderr',str(stderr),'--exit-code','0','--runner-exit-code','0']
    if case['selected_canary']:argv+=['--canary-file',str(canary),'--canary-expected',str(expected)]
    actual=subprocess.run(argv,cwd=root,capture_output=True,text=True)
    report=json.loads(actual.stdout)
    args=SimpleNamespace(runtime='claude',provider='synthetic',output=str(output),stderr=str(stderr),
        exit_code=0,runner_exit_code=0,wall_clock_seconds=None,last_message=None,artifact=[],
        canary_file=str(canary) if case['selected_canary'] else None,
        canary_expected=str(expected) if case['selected_canary'] else None)
    collection=module.Collection(args)
    internal_report=collection.collect()
    assert internal_report==report
    observed=report | {'exit_code':actual.returncode,'final_line':collection.final_line}
    mismatches={key:{'expected':value,'actual':observed[key]} for key,value in case['expected'].items()
                if value!=observed[key]}
    proofs=[d for d in report['errors'] if 'canary proof does not match expected token' in d['message']]
    missing=any('missing standalone canary report' in d['message'] for d in report['errors'])
    if case['selected_canary']:
        if missing:mismatches['missing_standalone_canary_report']={'expected':False,'actual':True}
        expected_proofs=int(case['name'].startswith('wrong-'))
        if len(proofs)!=expected_proofs:
            mismatches['mismatch_attribution_count']={'expected':expected_proofs,'actual':len(proofs)}
        elif proofs:
            assert (proofs[0]['stream'],proofs[0]['line'],proofs[0]['proof_line'],proofs[0]['path'])==('output',2,2,str(output))
    records.append({'name':case['name'],'raw_input_jsonl':raw,'runtime_stderr':'','argv':argv,
        'shell_display':shlex.join(argv),'cwd':str(root),'exit_code':actual.returncode,
        'stdout':actual.stdout,'stderr':actual.stderr,'final_line':collection.final_line,
        'final_valid':collection.final_valid,'terminal_valid':collection.terminal_valid,
        'expected':case['expected'],'mismatches':mismatches})
summary={'phase':phase,'current_source_sha256':hashlib.sha256(collector.read_bytes()).hexdigest(),
    'total_cases':len(records),'mismatch_cases':sum(bool(r['mismatches']) for r in records),
    'raw_snapshots':records,'scope':'Synthetic fixtures only; current repository collector executed for each case.'}
(run/'snapshot.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='raw_snapshots'},indent=2))
if phase=='before':
    assert summary['mismatch_cases']==57
    for record in records:
        assert not (set(record['mismatches'])-{'final_answer','final_answer_chars','final_line','canary_status',
                    'missing_standalone_canary_report','mismatch_attribution_count'})
else:
    assert summary['mismatch_cases']==0
