"""Compare saved synthetic reports, retaining every raw before/after value."""
import json
from pathlib import Path
p=Path(__file__).resolve().parent
before=json.loads((p/'probe-before/snapshot.json').read_text())
after=json.loads((p/'probe-after/snapshot.json').read_text())
rows=[]
controls=[]
for b,a in zip(before['raw_snapshots'],after['raw_snapshots']):
    assert b['name']==a['name'] and b['raw_input_jsonl']==a['raw_input_jsonl']
    br,ar=json.loads(b['stdout']),json.loads(a['stdout'])
    for key in ('validation_status','agent_status','result_status','runtime_exit_code','runner_exit_code','terminal','tool_results'):
        assert br[key]==ar[key],(a['name'],key)
    assert b['exit_code']==a['exit_code']
    assert (b['final_valid'],b['terminal_valid'])==(a['final_valid'],a['terminal_valid'])
    if not b['mismatches']:
        bn=json.dumps(br,sort_keys=True).replace('/probe-before/','/probe-PHASE/')
        an=json.dumps(ar,sort_keys=True).replace('/probe-after/','/probe-PHASE/')
        assert bn==an,a['name']
        controls.append(a['name'])
    rows.append({'case':a['name'],'before_final':br['final_answer'],'after_final':ar['final_answer'],
        'before_chars':br['final_answer_chars'],'after_chars':ar['final_answer_chars'],
        'before_final_line':b['final_line'],'after_final_line':a['final_line'],
        'before_canary':br['canary_status'],'after_canary':ar['canary_status'],
        'acceptance_and_proof_unchanged':True,'before_contract_mismatches':b['mismatches'],
        'after_contract_mismatches':a['mismatches']})
summary={'total':len(rows),'fixed_contract_mismatch_cases':before['mismatch_cases'],
    'remaining_contract_mismatch_cases':after['mismatch_cases'],'identical_complete_report_controls':controls,
    'report_path_comparison_rule':'Only the distinct probe-before/probe-after fixture directory segment is normalized for five unchanged controls.',
    'completion_exit_proof_not_assessed_unchanged_in_all_cases':True,'rows':rows}
assert json.loads((p/'differential.json').read_text())==summary
print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2))
