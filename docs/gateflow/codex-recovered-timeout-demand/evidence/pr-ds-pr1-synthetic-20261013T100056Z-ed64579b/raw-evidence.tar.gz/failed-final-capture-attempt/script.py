import ast, datetime, hashlib, json, subprocess
from pathlib import Path
root=Path.cwd()
p=root/'docs/gateflow/codex-recovered-timeout-demand/evidence/pr-ds-pr1-synthetic-20261013T100056Z-ed64579b'
before=json.loads((p/'before-manifest.json').read_text())
sources=list(before['sources'])
for path in sources:
    target=p/'final-source'/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((root/path).read_bytes())
unchanged={path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in before['unchanged_inputs']}
assert unchanged==before['unchanged_inputs'], 'An authoritative/controller input changed; investigate before delivery.'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip()
assert (head,branch)==(before['head'],before['branch'])
diff=subprocess.check_output(['git','diff','--',*sources])
(p/'source-delta.patch').write_bytes(diff)
(p/'git-status-final.txt').write_text(subprocess.check_output(['git','status','--short'],text=True))
numstat=subprocess.check_output(['git','diff','--numstat','--',*sources],text=True)
(p/'source-numstat.txt').write_text(numstat)
manifest={'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'branch':branch,
    'source_sha256':{path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in sources},
    'source_delta_sha256':hashlib.sha256(diff).hexdigest(),'numstat':numstat,
    'unchanged_input_sha256':unchanged,'unchanged_input_hashes_match_before':True,
    'unittest_methods_before':sum(isinstance(n,ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse((p/'before-source/tests/test_agent_run_results.py').read_text()))),
    'unittest_methods_after':sum(isinstance(n,ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse((root/'tests/test_agent_run_results.py').read_text()))),
    'runs':{folder.name:json.loads((folder/'result.json').read_text()) for folder in sorted((p/'runs').iterdir())}}
assert manifest['unittest_methods_before']==56 and manifest['unittest_methods_after']==57
for name,run in manifest['runs'].items():
    assert run['source_hashes_before']==run['source_hashes_after'],name
    assert run['exit_code']==(1 if name=='red-regression' else 0),name
    if name not in ('red-regression','probe-before'):
        assert run['source_hashes_after']==manifest['source_sha256'],name
(p/'final-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='runs'},indent=2))
