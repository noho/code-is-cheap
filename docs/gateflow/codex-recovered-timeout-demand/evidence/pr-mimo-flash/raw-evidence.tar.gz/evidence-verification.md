# Evidence verification (mimo-flash, PR 59)

All reads from exact head OID 2f0db8fb5fdfca02d90a69503b943aee348a81a0 via `git show <head>:<path>`. No working-copy substitution.

## Source hashes at head (verified)
| File | SHA-256 |
| --- | --- |
| scripts/agent-run-result.py | aa9b1a3eef7f048e6d8e8a06e06510da9178fcba9097270d422cf2eafc2dd7ff |
| tests/test_agent_run_results.py | 6cda405c565c9ebc200885bd61c1d8fe7e480b3562330afacd63e9ac38be891b |
| README.md | 73141fd5ffb4268bb6b610b5e0d1f30119d549c3158e0dc0c962ccb6f94f9bed |
| README.zh.md | 61ff31d06e68076db92fd3a215b25dc279b097c1ffe7ed0eda1db36ae75d52ea |
| skills/sub-agents/SKILL.md | cb812b367be37e7c6cdc5d919877a271b33aecd3ea6d8fc453b8aa3c6e8482db |

collector aa9b1a3e... matches the instructed source hash (verified, not assumed).

## Archive byte verification (extracted from exact head, not working copies)
| Archive | archive sha == index | files indexed | per-file sha ok |
| --- | --- | --- | --- |
| evidence/code-ds-flash/raw-evidence.tar.gz | true (433a8b57...) | 79 | 79/79 |
| evidence/aggregate-fix-ds-a1-.../raw-evidence.tar.gz | true (325ca65b...) | 88 | 88/88 |
| evidence/aggregate-ds-flash/raw-evidence.tar.gz | true (e423438f...) | 7 | 7/7 |
| evidence/aggregate-rereview-ds-flash/raw-evidence.tar.gz | true (9414cf27...) | 16 | 16/16 |
| evidence/controller-native/raw-evidence.tar.gz | true (9a148c99...) | 5 | 5/5 |
| evidence/controller-native-fixed/raw-evidence.tar.gz | true (dde8fe20...) | 5 | 5/5 |
| evidence/s1-implementation-20261013/raw-evidence.tar.gz | true | 58 | 58/58 |

All six archive_sha256 values match artifact-packaging.md. Directly versioned: controller-native{,-fixed}/summary.json + suite.stderr; s1 source-manifest.json, commands.json, unit-suite-final-source.log, static-checks.json, synthetic-samples.json (hashes recorded in shell log).

## Validation outcomes read at head
- s1 unit-suite-final-source.log: "Ran 56 tests ... OK", no FAIL/ERROR lines.
- controller-native-fixed/summary.json: actual_exit 0, collector_sha256 aa9b1a3e..., argv env AGENT_SANDBOX_KERNEL_TESTS=1 + SRT_TEST_BIN; suite.stderr: Ran 2 tests OK (claude_native_tools + codex_native_tools).
- original-replay-repository-fixed.json: exit 0, collector aa9b1a3e, completed/needs_review/not_assessed, errors 0 / anomalies 8 / warnings 0, 5 retained notices, all checks true, source_integrity_after == sources_sha256.
- judge-replay-repository-fixed.json: exit 0, collector aa9b1a3e, completed/needs_review/not_assessed, errors 0 / anomalies 10 / warnings 0, 4 TLS notices retained, line61 terminal/line60 final, all checks true, business_disposition: Developer and Judge remain caller-unaccepted.
- aggregate-fix validation.json (inside verified archive): affected-tests 0, synthetic 0, full-affected-suite 0 (56 passed), python-syntax 0, runner-syntax 0, diff-check 0.
- All *-run.json managed_exit 0 except plan-v2-fix-run.json = 1, explained by evidence/plan-v2-fix-native-proof.json: old installed collector false rejection (native exit0; only unknown Reconnecting diagnostic fatal in old report) — historical motivation for this work unit, documented, not hidden.
- pr-preflight.json: repo/base facts captured, remote main == 62c3b26a..., "refresh exact PR identity/compare at actual PR review" (done in this review).
