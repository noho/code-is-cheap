# DS-PR1 targeted actual-PR re-review evidence (ds-flash / Claude runtime)

Work unit `codex-recovered-timeout-demand`, draft PR59. Reviewed head
`aa7bcb747f41bba1ee1504005df5f938e8571aba`, base `62c3b26adeb994e81043d7b1afbcd4c6eb8974ae`.
Review artifact: `docs/reviews/pr-59-review-20261013-182754.md`. This directory holds only this
reviewer's own round-2 artifacts; no source, no other-route artifact, no raw other-agent log.

Contents (per-file SHA-256 in `evidence-inventory.sha256`, 25 files):

- `verification-notes.md`: full verification record (protocol, diff identity, fix archive, controller
  artifacts, archive reuse, own differential, Codex contract check, not-performed list).
- `compare-url.txt`, `pr-59-compare-rereview.diff` (completeDiffhash
  `c19f9e4b9c927061b8fbb32c34b2ff9385afd5ec5f7712e2a7c3e10cf1decd6f`),
  `local-diff-base-to-head.diff`, `completeness-rereview-check.txt`.
- `pr-facts-before.json`, `pr-facts-after.json`, `pr-facts-close.json` (OID requery triple),
  `checks-check-runs.json`, `checks-status.json`, `checks-suites.json`, `pr-59-body.md`.
- `snapshot-head/` (exact-head blobs via `git show`) + `snapshot-head.hashes.txt`;
  `source-delta-vs-original-reviewed.patch`, `tests-delta-vs-original-reviewed.patch`.
- `probe-ds-pr1-differential.json` / `.txt` + `tools/probe-ds-pr1.py`: independent 13-case
  before/after synthetic differential (original blob vs head blob).
- `tools/compare-diffs.py`: strict remote-vs-local diff comparison (label-only exception).
- `verify-ds-pr1-evidence.txt`, `verify-new-archives.txt`: archive/index verification outputs.

Retrieval: all paths are byte-stable in this directory; the compared archives live under the same
evidence root (`pr-ds-pr1-synthetic-20261013T100056Z-ed64579b`, `pr-ds-flash`, `pr-mimo-flash`,
`pr-controller-initial`, `pr-controller-verified`, `controller-native-pr-fixed`, plus the seven
unchanged pre-existing archives). Verification commands were run read-only; no evidence file was
modified after hashing, and the inventory excludes itself.
