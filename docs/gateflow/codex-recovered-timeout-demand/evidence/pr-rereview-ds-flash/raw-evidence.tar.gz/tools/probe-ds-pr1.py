#!/usr/bin/env python3
"""Independent DS-PR1 targeted differential for the PR59 re-review.

Runs the exact original-reviewed collector blob (2f0db8f, aa9b1a3e) and the
current PR-head collector blob (aa7bcb7, 406ec869) against reviewer-authored
SYNTHETIC Claude streams. No original business input, replay helper or
existing probe fixture is read. Verifies:

  - retention cases: empty joined root assistant text must not erase the
    earlier root partial / final_line / chars / canary attribution; the bug
    reproduces pre-fix and is gone post-fix;
  - control cases: valid readable result ownership (also under native
    negatives), tool-only, mixed empty+nonempty, nested, whitespace-only and
    duplicate/postterminal behavior are identical before/after, and
    acceptance status / exit codes / completion flags are unchanged.

Usage: python3 -I probe-ds-pr1.py <original_blob.py> <head_blob.py> <out.json>
"""

import json
import subprocess
import sys
import tempfile
from pathlib import Path

CANARY = "fresh-12345678"
PARTIAL = "partial root"
PARTIAL_CANARY = f"partial root\nCANARY={CANARY}"
PARTIAL_WRONG = "partial root\nCANARY=wrong-token"


def assistant(texts, parent=None, tool=None):
    blocks = [{"type": "text", "text": t} for t in texts]
    if tool is not None:
        blocks.append({"type": "tool_use", "id": tool, "name": "Bash", "input": {}})
    return {"type": "assistant", "message": {"content": blocks}, "parent_tool_use_id": parent}


def tool_result(identity, parent=None):
    return {"type": "user", "parent_tool_use_id": parent,
            "message": {"content": [{"type": "tool_result", "tool_use_id": identity,
                                     "content": "synthetic output", "is_error": False}]}}


def result(**fields):
    return {"type": "result", "subtype": "success", "is_error": False, **fields}


INIT = {"type": "system", "subtype": "init", "model": "fixture"}
EMPTY = assistant([""])
EMPTY3 = assistant(["", "", ""])

CASES = [
    ("retain-empty-noresult", [INIT, assistant([PARTIAL]), EMPTY], False),
    ("retain-empty-nonstring", [INIT, assistant([PARTIAL]), EMPTY3, result(result=42)], False),
    ("retain-empty-tool-blank", [INIT, assistant([PARTIAL]), assistant([""], tool="t"),
                                 tool_result("t"), result(result="  ")], False),
    ("canary-match-retained", [INIT, assistant([PARTIAL_CANARY]), EMPTY], True),
    ("canary-wrong-retained", [INIT, assistant([PARTIAL_WRONG]), EMPTY, result(result=[], )], True),
    ("ctrl-valid-result", [INIT, assistant([PARTIAL]), EMPTY, result(result="authoritative")], False),
    ("ctrl-native-negative", [INIT, assistant([PARTIAL]), EMPTY,
                              {**result(result="authoritative"), "stop_reason": "content_filter"}], False),
    ("ctrl-tool-only", [INIT, assistant([PARTIAL]), assistant([], tool="t"), tool_result("t"),
                        result(result="")], False),
    ("ctrl-mixed-frame", [INIT, assistant([PARTIAL]),
                          assistant(["", "new root", ""]), result(result="")], False),
    ("ctrl-nested-only", [INIT, assistant([PARTIAL]), assistant(["parent"], tool="p"),
                          assistant([""], parent="p"), assistant(["child text"], parent="p"),
                          tool_result("p"), result(result="")], False),
    ("ctrl-whitespace-then-empty", [INIT, assistant([PARTIAL]), assistant([" \t\n"]), EMPTY,
                                    result(result=42)], False),
    ("ctrl-postterminal-empty", [INIT, assistant([PARTIAL]), result(result="authoritative"),
                                 EMPTY], False),
    ("ctrl-conflict-second-empty", [INIT, assistant([PARTIAL]), result(result="first"),
                                    EMPTY, result(result="second")], False),
]

COMPARE = ("validation_status", "agent_status", "result_status", "terminal", "tool_results",
           "runner_exit_code", "events")


def run_case(blob, workdir, name, events, canary):
    out = workdir / f"{name}.jsonl"
    err = workdir / f"{name}.stderr"
    out.write_text("\n".join(json.dumps(e) for e in events) + "\n")
    err.write_text("")
    argv = [sys.executable, "-B", str(blob), "--runtime", "claude", "--provider", "ds-flash",
            "--output", str(out), "--stderr", str(err), "--exit-code", "0", "--runner-exit-code", "0"]
    if canary:
        cfile = workdir / f"{name}.canary"
        efile = workdir / f"{name}.expected"
        cfile.write_text(CANARY)
        efile.write_text(CANARY)
        argv += ["--canary-file", str(cfile), "--canary-expected", str(efile)]
    proc = subprocess.run(argv, capture_output=True, text=True, timeout=60,
                          cwd="/Users/leo/workspace/code-is-cheap")
    report = json.loads(proc.stdout)
    return {
        "case": name,
        "process_exit": proc.returncode,
        "final_answer": report["final_answer"],
        "final_answer_chars": report["final_answer_chars"],
        "canary_status": report["canary_status"],
        "mismatch_errors": [d for d in report["errors"]
                            if "canary proof does not match" in d["message"]],
        "missing_standalone": any("missing standalone canary report" in d["message"]
                                  for d in report["errors"]),
        "compared": {k: report[k] for k in COMPARE},
        "statuses": (report["validation_status"], report["agent_status"], report["result_status"]),
    }


def main():
    original_blob, head_blob, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
    workdir = Path(tempfile.mkdtemp(prefix="ds-pr1-rereview-"))
    rows = []
    for name, events, canary in CASES:
        before = run_case(original_blob, workdir, f"before-{name}", events, canary)
        after = run_case(head_blob, workdir, f"after-{name}", events, canary)
        same_compared = before["compared"] == after["compared"]
        row = {"case": name, "before": before, "after": after,
               "compared_fields_identical": same_compared}
        rows.append(row)
        print(f"{name:32s} before.final={before['final_answer']!r:40s} after.final={after['final_answer']!r:40s} "
              f"compare_same={same_compared}")
    retention = [r for r in rows if r["case"].startswith(("retain-", "canary-"))]
    controls = [r for r in rows if r["case"].startswith("ctrl-")]
    checks = {
        "retention_cases_reproduce_bug_before": all(r["before"]["final_answer"] == "" for r in retention),
        "retention_cases_retain_after": all(
            ("partial root" in r["after"]["final_answer"]) and r["after"]["final_answer_chars"] == len(r["after"]["final_answer"])
            for r in retention),
        "retention_rejected_failed_nonzero_after": all(
            r["after"]["statuses"][:2] == ("rejected", "failed") and r["after"]["process_exit"] == 1
            for r in retention),
        "controls_identical_before_after": all(r["compared_fields_identical"] for r in controls),
        "all_cases_acceptance_and_proof_unchanged": all(r["compared_fields_identical"] for r in rows),
        "canary_match_after": rows[3]["after"]["canary_status"] == "match",
        "canary_mismatch_attribution_after": rows[4]["after"]["mismatch_errors"] == [
            {**rows[4]["after"]["mismatch_errors"][0], "line": 2, "proof_line": 2}],
    }
    payload = {"original_blob": original_blob, "head_blob": head_blob, "rows": rows, "checks": checks}
    Path(out_path).write_text(json.dumps(payload, indent=1, ensure_ascii=False) + "\n")
    print(json.dumps(checks, indent=1))
    print("ALL_CHECKS_PASS:", all(checks.values()))
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
