#!/usr/bin/env python3
"""Reviewer-local diff comparison for PR59 re-review.

Compares the exact-OID GitHub compare diff snapshot against the local
`git diff base...head` output. The ONLY permitted difference is the
optional trailing section label after the closing `@@` of a hunk header
(e.g. GitHub renders `def ...` where local git renders `class ...`).
Hunk numeric ranges, content lines, file/index lines and ordering must
match byte-for-byte. Anything else is reported as a mismatch.

Usage: python3 -I compare-diffs.py <remote.diff> <local.diff> [report.txt]
"""

import sys


def split_hunk_header(line: str):
    """Return (numeric_ranges, closing_index) for a `@@ ... @@ label` line.

    Returns None when the line is not a hunk header.
    """
    if not line.startswith("@@"):
        return None
    end = line.find("@@", 2)
    if end == -1:
        return None
    ranges = line[2:end].strip()
    label = line[end + 2:].lstrip()
    return ranges, label


def main():
    remote_path, local_path = sys.argv[1], sys.argv[2]
    report_path = sys.argv[3] if len(sys.argv) > 3 else None

    with open(remote_path, "r", encoding="utf-8", errors="surrogateescape") as f:
        remote = f.read().split("\n")
    with open(local_path, "r", encoding="utf-8", errors="surrogateescape") as f:
        local = f.read().split("\n")

    out = []
    def log(s=""):
        out.append(s)

    log(f"remote_file={remote_path}")
    log(f"local_file={local_path}")
    log(f"remote_lines={len(remote)} local_lines={len(local)}")

    remote_files = [l for l in remote if l.startswith("diff --git ")]
    local_files = [l for l in local if l.startswith("diff --git ")]
    log(f"remote_diff_files={len(remote_files)} local_diff_files={len(local_files)}")
    if remote_files != local_files:
        log("FILELIST_ORDER_OR_CONTENT_MISMATCH")
        for i, (a, b) in enumerate(zip(remote_files, local_files)):
            if a != b:
                log(f"  first differing diff --git at index {i}:")
                log(f"    remote: {a}")
                log(f"    local : {b}")
                break
    else:
        log("FILELIST_IDENTICAL")

    normalized = 0
    mismatches = []
    numeric_range_ok = 0
    for i, (r, l) in enumerate(zip(remote, local)):
        if r == l:
            continue
        rh = split_hunk_header(r)
        lh = split_hunk_header(l)
        if rh and lh and rh[0] == lh[0]:
            normalized += 1
            numeric_range_ok += 1
            continue
        if len(mismatches) < 25:
            mismatches.append((i + 1, r, l))

    log(f"length_equal={'yes' if len(remote) == len(local) else 'no'}")
    log(f"normalized_hunk_label_lines={normalized}")
    log(f"real_mismatches={len(mismatches)}")

    # Byte totals of differing lines, to bound the delta size.
    remote_bytes_delta = 0
    for i, (r, l) in enumerate(zip(remote, local)):
        if r != l:
            remote_bytes_delta += len(r.encode("utf-8", "surrogateescape")) - len(l.encode("utf-8", "surrogateescape"))
    log(f"net_remote_minus_local_bytes={remote_bytes_delta}")

    for (lineno, r, l) in mismatches:
        log(f"MISMATCH at line {lineno}:")
        log(f"  remote: {r!r}")
        log(f"  local : {l!r}")

    verdict = (
        "NORMALIZED_COMPARE=PASS"
        if remote_files == local_files
        and len(remote) == len(local)
        and not mismatches
        and numeric_range_ok == normalized
        else "NORMALIZED_COMPARE=FAIL"
    )
    log(verdict)

    text = "\n".join(out) + "\n"
    print(text, end="")
    if report_path:
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(text)


if __name__ == "__main__":
    main()
