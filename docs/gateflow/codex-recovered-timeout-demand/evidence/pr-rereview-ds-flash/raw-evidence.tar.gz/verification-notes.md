# DS-PR1 targeted actual-PR re-review — verification notes (ds-flash / Claude runtime)

Work unit `codex-recovered-timeout-demand`, draft PR59, reviewed head `aa7bcb747f41bba1ee1504005df5f938e8571aba`
(base `62c3b26adeb994e81043d7b1afbcd4c6eb8974ae`), original independently reviewed head
`2f0db8fb5fdfca02d90a69503b943aee348a81a0`. All checks below are reviewer-executed in this round.
No source edit, delegation, commit, push, GitHub write, deployment, business-input read or raw
other-agent log was performed. Synthetic inputs only.

## Protocol and diff identity

- `gh` failed TLS verification inside the sandbox (`tls: failed to verify certificate`); the same
  GitHub REST endpoints were requested with `curl` + auth token, saving raw responses. No
  `gh pr diff`, no mutable-ref fallback.
- Facts before diff (`pr-facts-before.json`): repo `noho/code-is-cheap`, head repo same (not a fork),
  PR59 "fix(runners): decide call acceptance from native terminal state", author noho, head
  `fix/codex-recovered-timeout-demand` @ `aa7bcb74…`, base `main` @ `62c3b26a…`, draft, open,
  mergeable clean, 6 commits, 173 files, +10249/-1069, body sha256
  `62a4f2187da4a127cda46cd2b5003f6e92fed9681b380c653af2e1eb94442900`.
- Diff request (`compare-url.txt`): `GET https://api.github.com/repos/noho/code-is-cheap/compare/62c3b26adeb994e81043d7b1afbcd4c6eb8974ae...aa7bcb747f41bba1ee1504005df5f938e8571aba`,
  `Accept: application/vnd.github.v3.diff` → `pr-59-compare-rereview.diff`, 12500 lines / 1046238
  bytes / 173 file headers, SHA-256
  `c19f9e4b9c927061b8fbb32c34b2ff9385afd5ec5f7712e2a7c3e10cf1decd6f`.
- Local exact-OID diff `git diff 62c3b26a...aa7bcb74` → `local-diff-base-to-head.diff`, SHA-256
  `b71dd88e3a6f74c8fac0f5f161a7b6ed1c1c02f166c36077f012a019d2200c33`; numstat 173 files,
  +10249/-1069 == PR metadata; 6 commits base→head.
- Strict comparison (`tools/compare-diffs.py`, sha256
  `7c309a56a43abc47285b909504ab1735d532564a78037fb4a8acca5fa8855c7b`; report
  `completeness-rereview-check.txt`): file list identical, line counts identical, 10 differing lines
  are ONLY the optional hunk label after the closing `@@` with identical numeric ranges
  (`@@ -177,17 +143,16 @@ class Collection:` vs `def __init__…`), net +152 remote bytes. **NORMALIZED_COMPARE=PASS**
  (controlled label-only exception; no other normalization).
- OID requery after retrieval (`pr-facts-after.json`) and at close (`pr-facts-close.json`): head/base
  identical to before; PR OPEN/draft/MERGEABLE; 1 unique head/base pair across all three.
- Checks (`checks-check-runs.json`, `checks-status.json`, `checks-suites.json`): 0 check-runs,
  0 statuses (`state: pending`, empty list), 0 check-suites at head → no remote CI; no pass claimed.
- Body now states 57 current affected unit tests / 11 focused methods / 62 DS-PR1 synthetic
  differential cases / 2 native tests and records DS-PR1 re-review pending. Consistent with evidence.
- Deep-dive version source: `git show aa7bcb74…` blobs only (snapshot-head/); head blob hashes
  script `406ec8697cd516f335d3334b8a554353c9cc587d5e60428c4b9ba21e5817891d`, tests
  `a65efef0fa30fb631420fc8e786a825b1c31cfd67c555df66bd7af0c9b6678ea` == pr-fix.md current hashes.

## Delta vs original reviewed head (2f0db8f → aa7bcb7, one commit)

- Non-doc changed files: only `scripts/agent-run-result.py` (+3/-2) and
  `tests/test_agent_run_results.py` (+53/-0). All other deltas are docs/evidence/state.
- Source source-delta patch (`source-delta-vs-original-reviewed.patch` +
  `tests-delta-vs-original-reviewed.patch`) byte-identical (sha256 `184bba59…`) to the archived
  `source-delta.patch` of the fix delegate. Guard:
  `joined = "".join(text); if kind == "assistant" and root and joined:` replaces list truthiness.
- Runners `scripts/codex-agent-run`, `scripts/claude-agent-run`, `README.md`, `README.zh.md`,
  `tests/test_agent_sandbox_runtimes.py` blob-identical between the two heads (git rev-parse).

## Fix evidence archive verification (`pr-ds-pr1-synthetic-20261013T100056Z-ed64579b`)

- Archive sha256 `908861cc5bb62ab4386f2575910b866554e6c8057339b329f778d292bd84aaba` ==
  index claim; 78/78 members hash-identical to `raw-evidence-index.json`, no missing/extra
  (`verify-ds-pr1-evidence.txt`).
- `differential.json`: 62 rows; 57 fixed contract mismatches → 0 remaining; the 5 unchanged rows are
  the complete-report controls (valid-result, negative-result, tool-only, mixed-root, nested);
  `completion_exit_proof_not_assessed_unchanged_in_all_cases=true`; per-case before/after
  acceptance fields identical (0 fields differ).
- `probe-before/snapshot.json` 62 cases / 57 mismatches at collector `aa9b1a3e…`;
  `probe-after/snapshot.json` 62 cases / 0 mismatches at collector `406ec869…`; the 62 inputs are
  identical across phases (0 differing inputs).
- Run records: red-regression exit 1 (runner collector `aa9b1a3e` + final test file; 57 failures);
  affected-final exit 0 (`Ran 11 tests … OK`, 10.358 s); full-suite-final exit 0
  (`Ran 57 tests in 29.885s OK`, 0 skips); syntax-final exit 0; diff-check-final exit 0;
  capture-final exit 0; probe-before exit 0 (bug reproduced), probe-after exit 0, differential-final
  exit 0. All runs record source hashes before == after.
- `failed-final-capture-attempt/result.json`: exit 1 caused solely by concurrent controller-owned
  `state.json` hash drift (`a74b1f28…` → `2c23f385…`); binding inputs matched; that assertion was not
  rerun and no source/test check failed.
- `final-manifest.json` records source_delta_sha256 `184bba59…`, numstat `3/2 + 53/0`, methods
  56 → 57.

## Controller current-version artifacts (at head)

- `controller-native-pr-fixed/summary.json`: actual_exit 0, collector 406ec869, argv
  `python3 -B -m unittest discover -s tests -p test_agent_sandbox_runtimes.py -v`,
  `AGENT_SANDBOX_KERNEL_TESTS=1`; `suite.stderr`: `Ran 2 tests … OK` (Claude + Codex native tools).
- `original-replay-repository-pr-fixed.json`: actual_exit 0, collector 406ec869, 0/needs_review,
  completed/failed-completion 0, errors 0 / anomalies 8 / warnings 0, canary match, 5 notices
  retained, all 10 checks true (incl. final/session/usage/tools/artifacts unchanged, original
  inputs unchanged).
- `judge-replay-repository-pr-fixed.json`: actual_exit 0, collector 406ec869, 0/needs_review,
  errors 0 / anomalies 10 / warnings 0, 4 TLS notices retained, unique terminal line 61 / final
  line 60, all 11 checks true.
- Diff of `*-fixed` → `*-pr-fixed` for both replays: the ONLY changed line is `collector_sha256`
  (`aa9b1a3e…` → `406ec869…`); every computed check/notice/summary byte-identical.

## Evidence archive reuse verification

- 7 pre-existing archives (code-ds-flash, aggregate-ds-flash, aggregate-rereview-ds-flash,
  aggregate-fix-ds-a1-…, controller-native, controller-native-fixed, s1-implementation-20261013)
  are blob-identical between `2f0db8f` and `aa7bcb7` → unchanged; prior byte proof still applies.
- 5 new PR-era archives index-verified against their archives (`verify-new-archives.txt`):
  pr-ds-flash 38/38, pr-mimo-flash 10/10, pr-controller-initial 3/3, pr-controller-verified 7/7,
  controller-native-pr-fixed 5/5 — all PASS (archive sha == claim; no missing/extra/mismatch).
- My own earlier review evidence (`pr-ds-flash`): extracted from the archive and restored
  `reviewer-original-EVIDENCE.md` → `EVIDENCE.md` in scratch; original inventory
  (37 entries, absolute-path form) then passes 37/37; recorded original EVIDENCE.md hash
  `6049b86e…` == reviewer-original bytes. In the live worktree the only inventory mismatch is the
  root `EVIDENCE.md`, which is exactly the documented 5-line packaging wrapper.
- Binding inputs at head: goal-confirmation-v2.md `a68fd2c4…`, plan-v2.md `13748c8c…`,
  pr-review-decision.md `f68bf2e2…`, DS actual PR artifact
  `docs/reviews/pr-59-review-20261013-173833.md` `7d4ccce0…` — all equal pr-fix.md's recorded hashes.

## Independent reviewer differential (`probe-ds-pr1-differential.json` / `.txt`)

- `tools/probe-ds-pr1.py` (sha256 `d6e08bd5…`) runs the exact original blob (2f0db8f/aa9b1a3e) and
  head blob (aa7bcb7/406ec869) over 13 reviewer-authored synthetic streams (canary file/expected
  supplied for two).
- 6 retention cases: before display `''` → after retains partial (and canary text); still
  rejected/failed/exit 1/`result_status=not_assessed`.
- Canary: matching token → `match` (was `mismatch` + `missing standalone canary report` before);
  wrong token → precise `stream=output, line=2, proof_line=2` attribution on the retained frame.
- 7 controls (valid readable result, readable result under `content_filter` native negative,
  tool-only frame, mixed empty+nonempty frame, nested frames, whitespace-only then empty,
  post-terminal empty frame, conflicting second terminal): identical before/after on
  validation_status, agent_status, result_status, terminal, tool_results, runner_exit_code, events.
- Per-row `compared_fields_identical=true` for all 13 cases; ALL_CHECKS_PASS true.

## Codex-path check (unchanged by the fix)

- plan-v2.md §Codex final/terminal (lines 91, 196): "The last completed agent message before the
  terminal owns final; a blank latest final rejects even if an earlier message was nonempty.
  … invalid/blank latest cannot fall back."
- Implementation matches empirically (blank latest agent message after `earlier text` →
  `final_answer=''`, `invalid or empty completed agent message` + `missing valid complete final
  answer`, rejected/failed, exit 1). Identical assignment semantics exist at base `62c3b26`; the fix
  commit does not touch the Codex path. No finding; contract-conformant.

## Not performed / not claimed

- No full unit/native/original replay re-execution; no replay helper or original business input was
  run or read (the replay JSONs' recorded hashes/checks were verified, not regenerated).
- `live-before.json` (17:32) records installed collector `8a0be0d0` vs then-source `aa9b1a3e` and
  other components equal; installation/deployment is pending after full review. No installed/live
  pass is claimed by this review, and no transient network fault is reproduced.
- Other-route reviewer artifact (`pr-59-review-20261013-175536.md`) not read; controller adjudicates
  both routes.
