from pathlib import Path
src=Path('/private/tmp/shim-kimi-namespace-baseline/native-probe.py').read_text()
src=src.replace("ROOT = Path(__file__).resolve().parents[3]", "ROOT = Path('/Users/leo/workspace/code-is-cheap')")
src=src.replace("snapshots = ROOT / 'docs/gateflow/shim-subagent-all-providers/evidence/source-snapshots'", "snapshots = out / 'source-snapshots'")
a=src.index("    prompt = f'''")
b=src.index("    summary['parent_prompt']",a)
src=src[:a]+'''    prompt = f\'''KIMI_NAMESPACE_ROUTING_DIAGNOSTIC: explicitly authorized isolated native subagent test, not all-provider acceptance. Perform exactly this one task in sequence. Use the advertised native spawn_agent to create ONE fresh child, no inherited context (fork_context=false), omit model/reasoning overrides. Its complete task: "KIMI_NAMESPACE_ROUTING_DIAGNOSTIC. Reply exactly one line {initial}. Do not use tools, read/write files, or delegate." Use the advertised native wait_agent with the actual returned child ID and wait for its actual final. Finally report the observed child final. Parent may ONLY call native collaboration spawn_agent and wait_agent. No MCP resource lookup, shell, node, introspection, files, retries, repair, interrupt or close. This is explicitly authorized delegation. Follow actual descriptors and their required argument shapes.\'''
'''+src[b:]
src=src.replace("    wire, lock, local = [], threading.Lock(), threading.local()", "    wire, lock, local = [], threading.Lock(), threading.local()\n    namespace_records, response_records = [], []")
a=src.index("    def observe_open(req, timeout):")
b=src.index("    shim.fix_agent_messages, shim.upstream_open",a)
src=src[:a]+'''    def flatten(doc):
        # Diagnostic prototype only. No aliases, input/tool_choice changes or response rewrite.
        result = json.loads(json.dumps(doc))
        tools = result.get('tools')
        if not isinstance(tools, list):
            raise ValueError('prototype requires a tools array')
        names, expanded, flat, manifest = set(), 0, [], []
        for tool in tools:
            if not isinstance(tool, dict):
                raise ValueError('unknown non-object tool')
            if tool.get('type') != 'namespace':
                children = [tool]
            else:
                if set(tool) - {'type', 'name', 'description', 'tools'}:
                    raise ValueError('unknown namespace metadata')
                if not isinstance(tool.get('name'), str) or not tool['name']:
                    raise ValueError('invalid namespace name')
                if not isinstance(tool.get('description', ''), str) or not isinstance(tool.get('tools'), list):
                    raise ValueError('unknown namespace shape')
                children = []
                for child in tool['tools']:
                    if not isinstance(child, dict) or child.get('type') != 'function':
                        raise ValueError('unknown namespace child type')
                    if not isinstance(child.get('description', ''), str):
                        raise ValueError('unknown function description')
                    lifted = dict(child)
                    lifted['description'] = 'Namespace ' + tool['name'] + ': ' + tool.get('description', '') + '\\n\\n' + child.get('description', '')
                    children.append(lifted)
                expanded += 1
                manifest.append({'namespace': tool['name'], 'description': tool.get('description', ''), 'original': tool, 'flattened': children})
            for child in children:
                name = child.get('name')
                if child.get('type') == 'function':
                    if not isinstance(name, str) or not name or name in names:
                        raise ValueError('duplicate or invalid function name')
                    names.add(name)
                flat.append(child)
        result['tools'] = flat
        assert {k:v for k,v in doc.items() if k != 'tools'} == {k:v for k,v in result.items() if k != 'tools'}
        return result, manifest, expanded

    class TeeResponse:
        # Every byte obtained from installed Kimi is returned unchanged.
        def __init__(self, response, record):
            self.response, self.record = response, record
            self.pending, self.hasher, self.total = b'', hashlib.sha256(), 0
        def __getattr__(self, key):
            return getattr(self.response, key)
        def capture(self, data):
            self.hasher.update(data); self.total += len(data)
            self.record['stream_sha256'] = self.hasher.hexdigest()
            self.record['stream_bytes'] = self.total
            self.pending += data
            while b'\\n' in self.pending:
                line, self.pending = self.pending.split(b'\\n', 1)
                if not line.startswith(b'data: '): continue
                try: event = json.loads(line[6:])
                except ValueError: continue
                typ = event.get('type', '')
                item = event.get('item', {})
                # Raw function-call event lines only; never hidden reasoning/global context.
                if isinstance(item, dict) and item.get('type') == 'function_call':
                    self.record['raw_function_call_sse'].append(line.decode())
                if typ in ('response.created', 'response.completed', 'response.failed', 'error'):
                    resp = event.get('response', {})
                    self.record['lifecycle'].append({'type':typ, 'status':resp.get('status'), 'error':resp.get('error') or event.get('error'), 'output_types':[i.get('type') for i in resp.get('output', [])]})
            return data
        def read1(self, n=-1):
            return self.capture((getattr(self.response, 'read1', None) or self.response.read)(n))
        def read(self, n=-1):
            return self.capture(self.response.read(n))

    def observe_open(req, timeout):
        before = req.data
        enc = (req.get_header('Content-encoding') or '').lower()
        before = {'gzip': gzip.decompress, 'deflate': zlib.decompress}.get(enc, lambda x:x)(before)
        original_doc = json.loads(before)
        transformed, manifest, expanded = flatten(original_doc)
        body = json.dumps(transformed, ensure_ascii=False, separators=(',', ':')).encode() if expanded else before
        # urllib Request remains the same object/headers/URL. Content length is recomputed by urllib.
        req.data = {'gzip': gzip.compress, 'deflate': zlib.compress}.get(enc, lambda x:x)(body)
        record = getattr(local, 'record', None)
        attempt = {'pre_prototype_body_sha256':sha(before), 'body_sha256':sha(body), 'path':urllib.parse.urlsplit(req.full_url).path, 'model':transformed.get('model'), 'prototype':'request-only-unique-namespace-flatten-v1'}
        diag = {'thread_id': original_doc.get('client_metadata', {}).get('thread_id'), 'pre_sha256':sha(before), 'post_sha256':sha(body), 'namespace_manifest':manifest, 'expanded_count':expanded,
                'non_tools_fields_equal': {k:v for k,v in original_doc.items() if k != 'tools'} == {k:v for k,v in transformed.items() if k != 'tools'},
                'tool_choice_present': 'tool_choice' in original_doc, 'tool_choice':original_doc.get('tool_choice'),
                'parallel_tool_calls':original_doc.get('parallel_tool_calls'),
                'input_function_calls': [i for i in original_doc.get('input', []) if isinstance(i,dict) and i.get('type') in ('function_call','function_call_output')],
                'pre_tools_sha256':sha(json.dumps(original_doc['tools'],sort_keys=True)), 'post_tools_sha256':sha(json.dumps(transformed['tools'],sort_keys=True))}
        with lock: namespace_records.append(diag)
        if record is not None:
            record['pre_prototype_body_verified'] = sha(before) == record['expected_outbound_sha256']
            # The baseline observer DOES NOT cover our post-observer mutation.
            record['actual_upstream_body_verified'] = sha(body) == record['expected_outbound_sha256']
            record['prototype_actual_outbound_sha256'] = sha(body)
            record['outbound_attempts'].append(attempt)
            record['lite_header_observed'] = {k:v for k,v in req.header_items() if 'lite' in k.lower()}
        try:
            response = original_open(req, timeout)
            attempt['http_status'] = response.status
            capture = {'thread_id':diag['thread_id'], 'request_body_sha256':sha(body), 'http_status':response.status, 'raw_function_call_sse':[], 'lifecycle':[], 'response_rewrite':False}
            with lock: response_records.append(capture)
            return TeeResponse(response, capture)
        except Exception as exc:
            attempt['error_class'] = type(exc).__name__
            attempt['http_status'] = getattr(exc, 'code', None)
            raise

'''+src[b:]
src=src.replace("summary = {'schema': 2,", "summary = {'diagnostic_only':True, 'prototype':'request-only-unique-namespace-flatten-v1; no response/SSE rewrite; not acceptance', 'schema': 2,")
src=src.replace("('wire',wire),", "('namespace-transform',namespace_records),('response-native-calls',response_records),('wire',wire),")
Path('/private/tmp/shim-kimi-namespace-work/native-probe.py').write_text(src)
Path('/private/tmp/shim-kimi-namespace-work/audit-native-evidence.py').write_bytes(Path('/private/tmp/shim-kimi-namespace-baseline/audit-native-evidence.py').read_bytes())
