from pathlib import Path
import gzip,hashlib,json
ROOT=Path('/Users/leo/workspace/code-is-cheap');OUT=ROOT/'docs/gateflow/shim-subagent-all-providers/evidence/kimi-namespace-diagnostic';WORK=Path('/private/tmp/shim-kimi-namespace-work')
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
snapshots=OUT/'diagnostic-scripts';snapshots.mkdir(exist_ok=True)
for name in ['build-harness.py','package-evidence.py','final-check.py']:
 data=(WORK/name).read_bytes();(snapshots/(sha(data)+'.py.gz')).write_bytes(gzip.compress(data,mtime=0))
launch=json.loads((OUT/'attempt-1/launch.json').read_text());harness=WORK/'native-probe.py'
assert launch['version']=='codex-cli 0.167.0'
assert launch['source_hashes_at_launch'][str(harness)]==sha(harness.read_bytes())
snaps=list((OUT/'attempt-1/source-snapshots').glob('*.py.gz'));assert len(snaps)==1
assert sha(gzip.decompress(snaps[0].read_bytes()))==launch['source_hashes_at_launch'][str(harness)]
for file in OUT.rglob('*.json'):json.loads(file.read_text())
helper=ROOT/'codex-agent/bin/codex-auto-review-shim'
assert sha(helper.read_bytes())=='cd8e9f218c5a65d65bceff6ffac8b723c075913dad7ca08d999941ee34544dda'
paths=[helper, ROOT/'codex-agent/shim-routes.json',ROOT/'codex-agent/profiles/kimi/config.toml',ROOT/'codex-agent/model-providers.toml',Path('/Users/leo/.codex/model-catalogs/kimi.json')]
for p in paths:
 key=str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p)
 assert sha(p.read_bytes())==launch['source_hashes_at_launch'][key]
plan=ROOT/'docs/gateflow/shim-subagent-all-providers/kimi-namespace-plan.md'
for p in [plan,*OUT.rglob('*.json')]:
 assert all(line==line.rstrip() for line in p.read_text().splitlines()),p
 assert p.read_bytes().endswith(b'\n'),p
checks={'scope':'Diagnostic source integrity and evidence consistency only; no production test suite run','version':launch['version'],'harness_snapshot_matches_launch':True,'json_parse':True,'production_helper_unchanged':True,'route_profile_registry_catalog_hashes_unchanged_since_launch':True,'new_test_ids_only':[launch['parent_id']],'concurrency':'One Kimi profile; no other native profile started by this delegate','all_attempts_retained':['namespace-prototype-1'],'no_native_success_claim':True,'no_production_implementation':True,'no_response_rewrite':True,'auth_values_in_evidence':False,'private_destination':'Only equality/key-present booleans and wire model retained','files_at_final':{str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p):sha(p.read_bytes()) for p in paths},'baseline_copies':{str(p):sha(p.read_bytes()) for p in Path('/private/tmp/shim-kimi-namespace-baseline').glob('*.py')}}
dump(OUT/'final-check.json',checks)
manifest={str(p.relative_to(OUT)): {'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='manifest.json'}
dump(OUT/'manifest.json',manifest)
print(json.dumps({'files':len(manifest),'snapshot_sha256':sha(harness.read_bytes()),'helper_sha256':sha(helper.read_bytes()),'plan':str(plan),'checks':'pass'}))
