from pathlib import Path
import ast, copy, hashlib, json, subprocess
ROOT=Path('/Users/leo/workspace/code-is-cheap')
OUT=ROOT/'docs/gateflow/shim-subagent-all-providers/evidence/kimi-namespace-diagnostic'
ATT=OUT/'attempt-1'
WORK=Path('/private/tmp/shim-kimi-namespace-work')
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def write(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
# Retain exact native namespace schemas, but hash/omit unrelated global tool schemas.
p=ATT/'namespace-transform.json'
before=p.read_bytes(); transforms=read(p)
for r in transforms:
 for m in r['namespace_manifest']:
  if m['namespace'] != 'multi_agent_v1':
   m['function_names']=[x['name'] for x in m['flattened']]
   for k in ['original','flattened']:
    data=json.dumps(m[k],sort_keys=True,ensure_ascii=False).encode()
    m[k+'_sha256']=sha(data);m[k+'_json_bytes']=len(data);del m[k]
   m['description_sha256']=sha(m['description'].encode());del m['description']
   m['omitted']='Unrelated global tool descriptors omitted; original/flattened schema hashes and callable names retained. No native function-call evidence omitted.'
write(p,transforms)
write(OUT/'privacy-processing.json',{'file':'attempt-1/namespace-transform.json','before_sanitization_sha256':sha(before),'before_bytes':len(before),'after_sha256':sha(p.read_bytes()),'scope':'Only unrelated global namespace descriptors hash-omitted. Native multi_agent_v1 descriptors, all raw native function-call SSE lines and native call/result evidence retained. No hidden reasoning, global prompts, secrets or private endpoint URLs retained.'})
# Test only the diagnostic flatten function extracted from the exact launched source.
source=WORK/'native-probe.py';tree=ast.parse(source.read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');node=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='flatten')
ns={'json':json};exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns);flatten=ns['flatten']
fn={'type':'function','name':'spawn_agent','description':'original description','strict':False,'parameters':{'type':'object','properties':{'message':{'type':'string'}},'additionalProperties':False}}
wrapper={'type':'namespace','name':'multi_agent_v1','description':'native semantics','tools':[fn]}
doc={'model':'k3','tools':[wrapper,{'type':'function','name':'exec_command','parameters':{'type':'object'}}], 'tool_choice':'auto','parallel_tool_calls':True,'input':[{'type':'function_call','name':'spawn_agent','namespace':'multi_agent_v1','call_id':'diagnostic','arguments':'{}'}],'metadata':{'x':[1,2]},'stream':True}
original=copy.deepcopy(doc);fixed,manifest,count=flatten(doc)
checks={}
checks['input_immutable']=doc==original
checks['only_tools_changed']={k:v for k,v in fixed.items() if k!='tools'}=={k:v for k,v in doc.items() if k!='tools'}
checks['unique_original_name_retained']=fixed['tools'][0]['name']=='spawn_agent'
checks['function_schema_and_extra_fields_retained']={k:v for k,v in fixed['tools'][0].items() if k!='description'}=={k:v for k,v in fn.items() if k!='description'}
checks['namespace_semantics_description_retained']=fixed['tools'][0]['description']=='Namespace multi_agent_v1: native semantics\n\noriginal description'
checks['flat_tool_unchanged']=fixed['tools'][1]==doc['tools'][1]
checks['flat_request_semantic_noop']=flatten({'tools':[fn],'stream':True})[0]=={'tools':[fn],'stream':True}
for name,bad in {
 'duplicate_across_namespaces':{'tools':[wrapper,{'type':'namespace','name':'other','tools':[fn]}]},
 'duplicate_flat_and_namespace':{'tools':[wrapper,fn]},
 'nested_namespace':{'tools':[{'type':'namespace','name':'outer','tools':[wrapper]}]},
 'custom_child':{'tools':[{'type':'namespace','name':'outer','tools':[{'type':'custom','name':'x'}]}]},
 'unknown_namespace_metadata':{'tools':[{**wrapper,'future_semantics':True}]},
 'non_array_tools':{'tools':{}},
 'malformed_namespace_description':{'tools':[{**wrapper,'description':{}}]},
}.items():
 try:flatten(bad);checks[name+'_rejected']=False
 except ValueError:checks[name+'_rejected']=True
assert all(checks.values()),checks
write(OUT/'prototype-invariants.json',{'scope':'Offline diagnostic-harness invariants only, not production regression/acceptance','source_sha256':sha(source.read_bytes()),'checks':checks,'all_passed':True})
# Exact-version public source is corroboration; installed native observation is decisive.
srcdir=WORK/'source';tag=read(srcdir/'tag.json');commit=tag['object']['sha']
ranges={
 'tool_name.rs':('codex-rs/protocol/src/tool_name.rs',[(6,49)]),
 'models.rs':('codex-rs/protocol/src/models.rs',[(1134,1156)]),
 'router.rs':('codex-rs/core/src/tools/router.rs',[(270,303)]),
 'registry.rs':('codex-rs/core/src/tools/registry.rs',[(690,692),(768,788),(1148,1153)]),
 'spawn.rs':('codex-rs/core/src/tools/handlers/multi_agents/spawn.rs',[(24,35)]),
 'multi_agents_spec.rs':('codex-rs/core/src/tools/handlers/multi_agents_spec.rs',[(14,15),(85,94)]),
}
excerpts=[]
for filename,(repo_path,spans) in ranges.items():
 file=srcdir/filename;data=file.read_bytes();lines=data.decode().splitlines()
 excerpts.append({'path':repo_path,'url':'https://github.com/openai/codex/blob/'+commit+'/'+repo_path,'tag':'rust-v0.167.0','file_sha256':sha(data),'file_bytes':len(data),'excerpts':[{'start_line':a,'end_line':b,'text':'\n'.join(lines[a-1:b])} for a,b in spans]})
binpath=Path('/opt/homebrew/lib/node_modules/@openai/codex/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex')
write(OUT/'codex-routing-source.json',{'scope':'Public exact-version source corroboration, not gateway implementation evidence or a claim of a reproducible installed-binary build','tag_object':tag['sha'],'commit':commit,'observed_installed_version':subprocess.check_output(['codex','--version'],text=True).strip(),'installed_binary':{'path':str(binpath),'sha256':sha(binpath.read_bytes())},'files':excerpts,'source_fetch_notes':['spec.rs fetch returned404 because that legacy path does not exist; no source inference used from it.','No captured JavaScript executed. Offline code above executes only AST of the author-written diagnostic Python source.']})
summary=read(ATT/'summary.json');calls=read(ATT/'response-native-calls.json');rollouts=read(ATT/'rollouts-sanitized.json');native=read(ATT/'native-events.json');wire=read(ATT/'wire.json')
function_events=[json.loads(line[6:]) for r in calls for line in r['raw_function_call_sse']]
done=[e['item'] for e in function_events if e['type']=='response.output_item.done']
outputs=[e['item'] for r in rollouts for e in r['events'] if e.get('item',{}).get('type')=='function_call_output']
assert len(done)==1 and done[0]['name']=='spawn_agent' and 'namespace' not in done[0]
assert len(outputs)==1 and outputs[0]['call_id']==done[0]['call_id'] and outputs[0]['output']=='unsupported call: spawn_agent'
assert len(rollouts)==1 and not native
assert all(r['non_tools_fields_equal'] and r['tool_choice']=='auto' for r in transforms)
assert all(r['pre_prototype_body_verified'] and not r['actual_upstream_body_verified'] for r in wire)
write(OUT/'routing-verdict.json',{
 'diagnostic_only':True,'native_matrix_acceptance':False,'attempts':[{'attempt':'namespace-prototype-1','parent_id':summary['parent_id'],'native_version':summary['version'],'requests':len(wire),'http_statuses':[a['http_status'] for r in wire for a in r['outbound_attempts']],'runtime_exit':summary['app_server_exit'],'parent_turn_completed':summary['parent_completed'],'child_created':False,'native_collaboration_events':0,'bare_function_call':done[0],'matching_native_call_output':outputs[0],'routing_result':'FAIL: unsupported call: spawn_agent'}],
 'request_only_flattening_sufficient':False,'response_rewrite_performed':False,'tool_choice_observed':'auto (present; preserved exactly)','parallel_tool_calls_observed':True,'non_tools_fields_unchanged':True,
 'transport_boundary':'Candidate forwards to installed Kimi 127.0.0.1:8790/coding/v1/responses; installed route still owns private URL/key and upstream kimi-k3. Observer does not expose internal vendor gateway code.',
 'effective_endpoint':summary['effective_endpoint'],'policy':'Original card/catalog; read-only, approval never as baseline Kimi probe, inherited approvals_reviewer auto_review, max effort. No forced v2/Lite/Code Mode or disabling review.',
 'source_hashes':summary['source_hashes_at_launch'],'baseline_probe_sha256':sha(Path('/private/tmp/shim-kimi-namespace-baseline/native-probe.py').read_bytes()),'baseline_auditor_sha256':sha(Path('/private/tmp/shim-kimi-namespace-baseline/audit-native-evidence.py').read_bytes()),
 'important_observer_boundary':'Baseline expected_outbound_sha256 intentionally refers to pre-prototype bytes. Its actual_upstream_body_verified is false. Prototype pre/post hashes plus explicit transform manifest, exact prototype source and raw native-call SSE provide the new evidence. No baseline observer/auditor acceptance claimed.',
 'inference_limits':['The actual missing namespace caused this installed Codex bare call to fail routing.','Request-only flattening improved observed emission from no spawn to a real spawn_agent call but did not create a child.','No claim about internal gateway code or that model refusal alone explains the original failure.','A bridge restoring namespace is a proposed next design, not implemented or native-validated here.','No full A/B, native file-read or all-provider acceptance run performed.']})
print(json.dumps({'evidence':str(OUT),'diagnostic_parent':summary['parent_id'],'routing':'unsupported call: spawn_agent','offline_checks':len(checks),'passed':all(checks.values())}))
