#!/usr/bin/env python3
"""Isolated real-model probe, chaining a candidate to the selected installed route.

No private settings writes, deployment, forced catalog/tool modes, synthetic SSE,
child RPC or automatic retries. Only newly created test threads are inspected.
"""
import argparse
import collections
import gzip
import hashlib
import importlib.machinery
import importlib.util
import json
from pathlib import Path
import queue
import subprocess
import sys
import tempfile
import threading
import time
import tomllib
import urllib.parse
import uuid
import zlib

ROOT = Path('/Users/leo/workspace/code-is-cheap')


def sha(value):
    return hashlib.sha256(value.encode() if isinstance(value, str) else value).hexdigest()


def load(name, path):
    loader = importlib.machinery.SourceFileLoader(name, str(path))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


def changes(before, after, path=()):
    """Exact changed leaves; values are hashed to avoid saving global context."""
    if before == after:
        return []
    if isinstance(before, dict) and isinstance(after, dict) and before.keys() == after.keys():
        return [v for k in before for v in changes(before[k], after[k], (*path, k))]
    if isinstance(before, list) and isinstance(after, list) and len(before) == len(after):
        return [v for k in range(len(before)) for v in changes(before[k], after[k], (*path, k))]
    return [{'path': list(path), 'before_sha256': sha(json.dumps(before, ensure_ascii=False, sort_keys=True)),
             'after_sha256': sha(json.dumps(after, ensure_ascii=False, sort_keys=True)), 'before': before, 'after': after}]



def native_supplement(ids):
    """Only allowlisted native events from explicitly known new test threads."""
    supplements = []
    for tid in sorted(ids):
        for path in (Path.home()/'.codex/sessions').glob(f'*/*/*/*{tid}.jsonl'):
            events = []
            for line, raw in enumerate(path.read_text().splitlines(), 1):
                item = json.loads(raw)
                p = item.get('payload', {})
                if item['type'] != 'event_msg':
                    continue
                if p.get('type') == 'item_completed' and p.get('item', {}).get('type') in ('CommandExecution', 'SubAgentActivity', 'CollabAgentToolCall'):
                    events.append({'line': line, 'event': p})
                if p.get('type') == 'thread_settings_applied':
                    settings = p['thread_settings']
                    events.append({'line': line, 'settings': {k:settings.get(k) for k in ('model','model_provider_id','reasoning_effort','approval_policy','approvals_reviewer','permission_profile','cwd')}})
            supplements.append({'thread_id':tid, 'source_rollout_sha256':sha(path.read_bytes()), 'events':events})
    return supplements


def candidate_route(route):
    """Preserve the installed incoming prefix by omitting stripping metadata."""
    candidate = {**route, 'listen': '127.0.0.1:0',
                 'upstream': f'http://127.0.0.1:{route["port"]}', 'from': 'codex-auto-review'}
    candidate.pop('endpoint_id')
    candidate.pop('request_prefix')
    return candidate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', default='ds-flash')
    parser.add_argument('--evidence-dir', type=Path)
    parser.add_argument('--attempt', default='1')
    args = parser.parse_args()
    routes_path = ROOT / 'codex-agent/shim-routes.json'
    route = next(r for r in json.loads(routes_path.read_text())['routes'] if r['endpoint_id'] == args.profile)
    card_path = ROOT / 'codex-agent/profiles' / args.profile / 'config.toml'
    card = tomllib.loads(card_path.read_text().replace('@HOME@', str(Path.home())))
    provider = card['model_provider']
    registry_path = ROOT / 'codex-agent/model-providers.toml'
    registry = tomllib.loads(registry_path.read_text())['model_providers'][provider]
    assert registry['base_url'] == f'http://127.0.0.1:{route["port"]}' + route['request_prefix'], 'profile registry/route mismatch'
    catalog = Path(card['model_catalog_json'])
    selected = next(m for m in json.loads(catalog.read_text())['models'] if m['slug'] == card['model'])
    out = args.evidence_dir or Path(tempfile.mkdtemp(prefix='shim-native-' + args.profile + '-'))
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'summary.json').exists():
        parser.error('Evidence directory already has an attempt; choose a new directory')
    cwd = Path(tempfile.mkdtemp(prefix='shim-fixture-' + args.profile + '-'))
    fixture = cwd / 'harmless-target.txt'
    fixture_text = 'HARMLESS_NATIVE_CONTENT_' + uuid.uuid4().hex
    fixture.write_text(fixture_text)
    token = 'LIVE_MESSAGE_OK_' + uuid.uuid4().hex[:12]
    initial, followup = ('LIVE_INITIAL_' + uuid.uuid4().hex[:12], 'LIVE_FOLLOWUP_' + uuid.uuid4().hex[:12])
    shim_path = ROOT / 'codex-agent/bin/codex-auto-review-shim'
    shim = load('candidate_shim', shim_path)
    shim.FAILED_DIR = str(cwd / 'failed')
    dumps = []
    # Failures retain content hashes, never full global prompts/contexts.
    def observe_dump(self, payload, status, kind='req'):
        dumps.append({'kind':kind, 'status':status, 'sha256':sha(payload), 'bytes':len(payload)})
    shim.Handler._dump = observe_dump
    endpoint = shim.endpoint_module()
    # Retain only the selected model and equality check, never URL/key.
    connection = endpoint.connection(args.profile, 'codex', require_key=True)
    effective = {'wire_model': connection['upstream_model'], 'key_present': bool(connection['api_key'])}
    if args.profile == 'kimi':
        ds = endpoint.connection('ds-flash', 'codex', require_key=True)
        effective['user_override_destination_equals_ds_flash'] = connection['base_url'] == ds['base_url'] and connection['api_key'] == ds['api_key']
        del ds
    del connection
    wire, lock, local = [], threading.Lock(), threading.local()
    namespace_records, response_records = [], []
    original_fix, original_open = shim.fix_agent_messages, shim.upstream_open

    def observe_fix(body):
        converted, count = original_fix(body)
        doc, fixed = json.loads(body), json.loads(converted)
        expected = converted
        swapped, how = shim._swap(expected, 'codex-auto-review', route['to'])
        stages = [{'flag': 'model_swap', 'enabled': True, 'count': int(how != 'none'), 'before_sha256': sha(expected), 'after_sha256': sha(swapped), 'changes': changes(json.loads(expected), json.loads(swapped))}]
        expected = swapped
        for flag, func in (('id_fix', shim.fix_message_ids), ('json_fmt_fix', shim.json_object_format), ('drop_tools_item', shim.drop_tools_item)):
            before = expected
            expected, n = func(before) if route.get(flag) else (before, 0)
            stages.append({'flag': flag, 'enabled': route.get(flag, False), 'count': n,
                           'before_sha256': sha(before), 'after_sha256': sha(expected),
                           'changes': changes(json.loads(before), json.loads(expected))})
        items = [{'index': i, 'ingress': b, 'egress': a} for i, (b, a) in enumerate(zip(doc.get('input', []), fixed.get('input', []))) if isinstance(b, dict) and b.get('type') == 'agent_message']
        record = {'thread_id': doc.get('client_metadata', {}).get('thread_id'), 'ingress_sha256': sha(body),
                  'egress_sha256': sha(converted), 'expected_outbound_sha256': sha(expected),
                  'model': doc.get('model'), 'stream': doc.get('stream'), 'converted': count, 'items': items,
                  'types': dict(collections.Counter(i.get('type') for i in doc.get('input', []) if isinstance(i, dict))),
                  'non_target_items_equal': len(doc.get('input', [])) == len(fixed.get('input', [])) and all(b == a for b, a in zip(doc.get('input', []), fixed.get('input', [])) if not isinstance(b, dict) or b.get('type') != 'agent_message'),
                  'non_input_fields_equal': {k:v for k,v in doc.items() if k != 'input'} == {k:v for k,v in fixed.items() if k != 'input'},
                  'stages': stages, 'outbound_attempts': []}
        # Native descriptor source is retained, not full prompts or global tools.
        tools = [t for t in doc.get('tools', []) if t.get('name') in ('spawn_agent', 'send_input', 'followup_task', 'send_message', 'wait', 'wait_agent', 'list_agents', 'exec', 'exec_command', 'multi_agent_v1', 'collaboration', 'functions')]
        for item in doc.get('input', []):
            if item.get('type') == 'additional_tools':
                tools += [t for t in item.get('tools', []) if t.get('name') in ('functions', 'collaboration', 'multi_agent_v1')]
        record['native_descriptors'] = tools
        record['lite_header_observed'] = None
        with lock:
            wire.append(record)
        local.record = record
        return converted, count

    def flatten(doc):
        # Diagnostic prototype only. No aliases, input/tool_choice changes or response rewrite.
        result = json.loads(json.dumps(doc))
        tools = result.get('tools')
        if not isinstance(tools, list):
            raise ValueError('prototype requires a tools array')
        names, expanded, flat, manifest = set(), 0, [], []
        for tool in tools:
            if not isinstance(tool, dict):
                raise ValueError('unknown non-object tool')
            if tool.get('type') != 'namespace':
                children = [tool]
            else:
                if set(tool) - {'type', 'name', 'description', 'tools'}:
                    raise ValueError('unknown namespace metadata')
                if not isinstance(tool.get('name'), str) or not tool['name']:
                    raise ValueError('invalid namespace name')
                if not isinstance(tool.get('description', ''), str) or not isinstance(tool.get('tools'), list):
                    raise ValueError('unknown namespace shape')
                children = []
                for child in tool['tools']:
                    if not isinstance(child, dict) or child.get('type') != 'function':
                        raise ValueError('unknown namespace child type')
                    if not isinstance(child.get('description', ''), str):
                        raise ValueError('unknown function description')
                    lifted = dict(child)
                    lifted['description'] = 'Namespace ' + tool['name'] + ': ' + tool.get('description', '') + '\n\n' + child.get('description', '')
                    children.append(lifted)
                expanded += 1
                manifest.append({'namespace': tool['name'], 'description': tool.get('description', ''), 'original': tool, 'flattened': children})
            for child in children:
                name = child.get('name')
                if child.get('type') == 'function':
                    if not isinstance(name, str) or not name or name in names:
                        raise ValueError('duplicate or invalid function name')
                    names.add(name)
                flat.append(child)
        result['tools'] = flat
        assert {k:v for k,v in doc.items() if k != 'tools'} == {k:v for k,v in result.items() if k != 'tools'}
        return result, manifest, expanded

    class TeeResponse:
        # Every byte obtained from installed Kimi is returned unchanged.
        def __init__(self, response, record):
            self.response, self.record = response, record
            self.pending, self.hasher, self.total = b'', hashlib.sha256(), 0
        def __getattr__(self, key):
            return getattr(self.response, key)
        def capture(self, data):
            self.hasher.update(data); self.total += len(data)
            self.record['stream_sha256'] = self.hasher.hexdigest()
            self.record['stream_bytes'] = self.total
            self.pending += data
            while b'\n' in self.pending:
                line, self.pending = self.pending.split(b'\n', 1)
                if not line.startswith(b'data: '): continue
                try: event = json.loads(line[6:])
                except ValueError: continue
                typ = event.get('type', '')
                item = event.get('item', {})
                # Raw function-call event lines only; never hidden reasoning/global context.
                if isinstance(item, dict) and item.get('type') == 'function_call':
                    self.record['raw_function_call_sse'].append(line.decode())
                if typ in ('response.created', 'response.completed', 'response.failed', 'error'):
                    resp = event.get('response', {})
                    self.record['lifecycle'].append({'type':typ, 'status':resp.get('status'), 'error':resp.get('error') or event.get('error'), 'output_types':[i.get('type') for i in resp.get('output', [])]})
            return data
        def read1(self, n=-1):
            return self.capture((getattr(self.response, 'read1', None) or self.response.read)(n))
        def read(self, n=-1):
            return self.capture(self.response.read(n))

    def observe_open(req, timeout):
        before = req.data
        enc = (req.get_header('Content-encoding') or '').lower()
        before = {'gzip': gzip.decompress, 'deflate': zlib.decompress}.get(enc, lambda x:x)(before)
        original_doc = json.loads(before)
        transformed, manifest, expanded = flatten(original_doc)
        body = json.dumps(transformed, ensure_ascii=False, separators=(',', ':')).encode() if expanded else before
        # urllib Request remains the same object/headers/URL. Content length is recomputed by urllib.
        req.data = {'gzip': gzip.compress, 'deflate': zlib.compress}.get(enc, lambda x:x)(body)
        record = getattr(local, 'record', None)
        attempt = {'pre_prototype_body_sha256':sha(before), 'body_sha256':sha(body), 'path':urllib.parse.urlsplit(req.full_url).path, 'model':transformed.get('model'), 'prototype':'request-only-unique-namespace-flatten-v1'}
        diag = {'thread_id': original_doc.get('client_metadata', {}).get('thread_id'), 'pre_sha256':sha(before), 'post_sha256':sha(body), 'namespace_manifest':manifest, 'expanded_count':expanded,
                'non_tools_fields_equal': {k:v for k,v in original_doc.items() if k != 'tools'} == {k:v for k,v in transformed.items() if k != 'tools'},
                'tool_choice_present': 'tool_choice' in original_doc, 'tool_choice':original_doc.get('tool_choice'),
                'parallel_tool_calls':original_doc.get('parallel_tool_calls'),
                'input_function_calls': [i for i in original_doc.get('input', []) if isinstance(i,dict) and i.get('type') in ('function_call','function_call_output')],
                'pre_tools_sha256':sha(json.dumps(original_doc['tools'],sort_keys=True)), 'post_tools_sha256':sha(json.dumps(transformed['tools'],sort_keys=True))}
        with lock: namespace_records.append(diag)
        if record is not None:
            record['pre_prototype_body_verified'] = sha(before) == record['expected_outbound_sha256']
            # The baseline observer DOES NOT cover our post-observer mutation.
            record['actual_upstream_body_verified'] = sha(body) == record['expected_outbound_sha256']
            record['prototype_actual_outbound_sha256'] = sha(body)
            record['outbound_attempts'].append(attempt)
            record['lite_header_observed'] = {k:v for k,v in req.header_items() if 'lite' in k.lower()}
        try:
            response = original_open(req, timeout)
            attempt['http_status'] = response.status
            capture = {'thread_id':diag['thread_id'], 'request_body_sha256':sha(body), 'http_status':response.status, 'raw_function_call_sse':[], 'lifecycle':[], 'response_rewrite':False}
            with lock: response_records.append(capture)
            return TeeResponse(response, capture)
        except Exception as exc:
            attempt['error_class'] = type(exc).__name__
            attempt['http_status'] = getattr(exc, 'code', None)
            raise

    shim.fix_agent_messages, shim.upstream_open = observe_fix, observe_open
    # The candidate has no endpoint_id: installed corresponding route owns auth
    # and logical->wire model remapping. Preserve its incoming prefix exactly.
    server = shim._make_server(candidate_route(route))
    port = server.server_address[1]
    server.route['port'] = port
    listener = threading.Thread(target=server.serve_forever)
    listener.start()
    version = subprocess.check_output(['codex', '--version'], text=True).strip()
    base_policy = tomllib.loads((Path.home()/'.codex/config.toml').read_text())
    # Keep auto-review where the model requires it; never disables node review.
    approval = base_policy.get('approval_policy', 'on-request') if selected.get('node_repl_auto_review_required') else 'never'
    settings = {**card, f'model_providers.{provider}.base_url': f'http://127.0.0.1:{port}' + route['request_prefix'],
                'features.apps': False, 'features.plugins': False, 'approval_policy': approval, 'sandbox_mode': 'read-only'}
    cmd = ['codex', 'app-server']
    for key,value in settings.items():
        cmd += ['-c', key + '=' + json.dumps(value)]
    hashes = {str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p): sha(p.read_bytes()) for p in (shim_path, routes_path, card_path, registry_path, catalog, Path(__file__), Path(__file__).with_name('audit-native-evidence.py'))}
    summary = {'diagnostic_only':True, 'prototype':'request-only-unique-namespace-flatten-v1; no response/SSE rewrite; not acceptance', 'schema': 2, 'profile': args.profile, 'attempt': args.attempt, 'source_head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
               'source_hashes_at_launch': hashes, 'version': version, 'model': card['model'], 'provider': provider, 'effort': card['model_reasoning_effort'],
               'catalog_selected': {k:selected.get(k) for k in ('slug','multi_agent_version','tool_mode','use_responses_lite','node_repl_auto_review_required','node_repl_disabled','shell_type')},
               'effective_endpoint': effective, 'route': route, 'cwd':str(cwd), 'candidate_port':port,
               'command': cmd, 'driver_argv': [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
               'settings': settings, 'inherited_approval_reviewer': base_policy.get('approvals_reviewer'),
               'fixture': {'path':str(fixture), 'contents':fixture_text, 'sha256':sha(fixture_text)},
               'initial_marker':initial,'followup_marker':followup,'message_token':token}
    snapshots = out / 'source-snapshots'
    snapshots.mkdir(parents=True, exist_ok=True)
    source_bytes = Path(__file__).read_bytes()
    (snapshots / (sha(source_bytes) + '.py.gz')).write_bytes(gzip.compress(source_bytes, mtime=0))
    (out/'launch.json').write_text(json.dumps(summary,indent=2))
    print('PROBE_DIR=' + str(out), flush=True)
    stderr = (out/'app-server.stderr').open('w')
    proc = subprocess.Popen(cmd,cwd=cwd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,text=True,bufsize=1)
    messages = queue.Queue()
    def reader():
        for line in proc.stdout:
            try: messages.put(json.loads(line))
            except ValueError: messages.put({'parse_error':True})
        messages.put(None)
    thread = threading.Thread(target=reader); thread.start()
    def send(method,params,request_id=None):
        msg = {'method':method,'params':params}
        if request_id is not None: msg['id']=request_id
        proc.stdin.write(json.dumps(msg)+'\n'); proc.stdin.flush()
    prompt = f'''KIMI_NAMESPACE_ROUTING_DIAGNOSTIC: explicitly authorized isolated native subagent test, not all-provider acceptance. Perform exactly this one task in sequence. Use the advertised native spawn_agent to create ONE fresh child, no inherited context (fork_context=false), omit model/reasoning overrides. Its complete task: "KIMI_NAMESPACE_ROUTING_DIAGNOSTIC. Reply exactly one line {initial}. Do not use tools, read/write files, or delegate." Use the advertised native wait_agent with the actual returned child ID and wait for its actual final. Finally report the observed child final. Parent may ONLY call native collaboration spawn_agent and wait_agent. No MCP resource lookup, shell, node, introspection, files, retries, repair, interrupt or close. This is explicitly authorized delegation. Follow actual descriptors and their required argument shapes.'''
    summary['parent_prompt']=prompt
    parent_id, done, errors, native_events = None, False, [], []
    started=time.time()
    try:
        send('initialize', {'clientInfo':{'name':'shim_native_candidate','title':'Shim native candidate','version':'2'},'capabilities':{'experimentalApi':True}},0)
        while True:
            try: msg=messages.get(timeout=30)
            except queue.Empty:
                print(f'WAITING elapsed={int(time.time()-started)} requests={len(wire)}',flush=True); continue
            if msg is None:
                errors.append({'process_eof_before_completed':not done}); break
            if msg.get('error'):
                errors.append(msg['error']); break
            if msg.get('id')==0 and 'result' in msg:
                send('initialized',{})
                send('thread/start',{'model':card['model'],'modelProvider':provider,'cwd':str(cwd),'sandbox':'read-only','approvalPolicy':approval,'experimentalRawEvents':True},1)
            if msg.get('id')==1 and 'result' in msg:
                parent_id=msg['result']['thread']['id'];summary['thread_start_identity']={k:msg['result'].get(k) for k in ('model','modelProvider','reasoningEffort','approvalPolicy','sandbox')}
                print('PARENT_ID='+parent_id,flush=True)
                send('turn/start',{'threadId':parent_id,'input':[{'type':'text','text':prompt}]},2)
            # Retain only native execution/collaboration events of this new run.
            method=msg.get('method','')
            params=msg.get('params',{})
            event=params.get('msg',{})
            et=event.get('type','') if isinstance(event,dict) else ''
            if method.startswith('codex/event/') and any(s in et for s in ('exec_command','mcp_tool_call','collab','tool_call','task_complete')):
                native_events.append(msg)
            if method=='turn/completed' and params.get('threadId')==parent_id:
                done=True; summary['parent_turn_status']=params['turn']['status']
                summary['parent_turn_error']=params['turn'].get('error')
                if summary['parent_turn_status']!='completed': errors.append({'turn_status':summary['parent_turn_status']})
                break
    finally:
        proc.stdin.close();code=proc.wait();thread.join();stderr.close()
        server.shutdown();server.server_close();listener.join()
    ids={r['thread_id'] for r in wire if r.get('thread_id')}
    if parent_id: ids.add(parent_id)
    rollouts=[]
    for tid in sorted(ids):
        for path in (Path.home()/'.codex/sessions').glob(f'*/*/*/*{tid}.jsonl'):
            events,identity,contexts=[],{},[]
            for lineno,line in enumerate(path.read_text().splitlines(),1):
                item=json.loads(line);p=item.get('payload',{});typ=item['type']
                if typ=='session_meta': identity={k:p.get(k) for k in ('id','parent_thread_id','cli_version','model_provider','agent_path','source','cwd')}
                if typ=='turn_context': contexts.append({k:p.get(k) for k in ('turn_id','model','model_provider','effort','approval_policy','sandbox_policy')})
                if typ=='response_item' and (p.get('type') in ('agent_message','function_call','function_call_output','custom_tool_call','custom_tool_call_output') or p.get('type')=='message' and p.get('role')=='assistant'):
                    events.append({'line':lineno,'item':p})
                if typ=='event_msg' and (p.get('type') in ('task_started','task_complete') or any(s in p.get('type','') for s in ('exec_command','mcp_tool_call','collab','tool_call'))):
                    events.append({'line':lineno,'event':p})
            rollouts.append({'file':path.name,'identity':identity,'contexts':contexts,'events':events})
    summary.update(parent_id=parent_id,app_server_exit=code,errors=errors,parent_completed=done and not errors and code==0,elapsed_seconds=round(time.time()-started,2),request_count=len(wire))
    for name,value in (('namespace-transform',namespace_records),('response-native-calls',response_records),('wire',wire),('rollouts-sanitized',rollouts),('native-events',native_events),('dump-metadata',dumps),('native-rollout-supplement',native_supplement(ids)),('summary',summary)):
        (out/(name+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2))
    print(json.dumps({'profile':args.profile,'parent_completed':summary['parent_completed'],'app_server_exit':code,'errors':errors,'requests':len(wire),'elapsed_seconds':summary['elapsed_seconds']}),flush=True)
    return 0 if summary['parent_completed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
