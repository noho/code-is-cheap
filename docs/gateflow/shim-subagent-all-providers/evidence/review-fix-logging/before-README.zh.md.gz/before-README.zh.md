# code-is-cheap

[English](README.md) | 中文

面向 Codex / Claude Code 的多模型 Agent 工具与自动化 AI Coding 工程控制框架。

## 功能介绍

### 常见模型的 Claude Code / Codex 运行入口

为各 runtime 支持的常见模型提供统一的启动入口，例如 `mimo_claude`、`ds-flash_codex` 和 `gpt_codex`。
可以按任务选择模型，在熟悉的 Claude Code / Codex CLI 中交互，也可以通过 runner 托管非交互任务。
第三方模型的上游 URL、模型 ID 和 API key 由本机私有连接配置管理，便于切换支持相应 API 的云商。
GPT/business profiles 保持使用 Codex 账号登录与模型卡；各 runtime 的可用入口见后文表格。

### sub-agents SKILL 代替内置子 Agent

不同模型擅长不同的任务，内置子 Agent 的选择范围与路由方式受所在 runtime 限制。
`sub-agents` 通过 `claude-agent-run` / `codex-agent-run` 启动外部子 Agent，让 Orchestrator 按任务选择 provider 和 runtime，
替代工作流中的内置子 Agent 派发方式。

更重要的是，大规模 AI workflow 会消耗大量 token，没有必要让所有步骤都使用昂贵模型。
可以把需要强推理的任务交给高能力模型，把检索、整理、例行检查等任务分配给更经济的模型；
总控负责检查结果、裁决分歧和验收产物。

### 更严格的子 Agent 隔离运行

大型 AI workflow 经常要求角色之间独立判断，不能让其他角色的结论污染上下文。
例如 Agent A 生成题目与答案，Agent B 独立作答时可以读取题目，但必须禁止读取 A 的答案、分析和历史记录。

Codex / Claude Code 的默认沙箱、工作目录或 prompt 中的禁读约定，并不等同于这种任务级读取边界。
在 **macOS** 上，code-is-cheap 提供可选的 `agent-sandbox` 封装：调用方用 `--deny-list` 声明禁止读取的文件或目录，
在文件系统访问层阻止读取，并在内核禁读验证通过后才启动 runner；保留原有写入限制的保守子集。
需要先安装固定版本 srt；普通 runner 调用不会自动启用此能力。调用方还须列出已知副本，未列出的副本仍可读取。
详见后文「可选任务禁读边界（macOS）」。

### Agent 之间通讯功能

通过 `tmux-agents` 和 `tmux-cli`，已运行的 CLI Agent 可以互发 prompt、等待响应并读取反馈。
一个典型场景是：A 项目使用 B 项目的功能，A 的 Agent 发现 bug 后，把复现证据与修复请求发给 B 的 Agent；
收到修复结果后，A 的 Agent 再验证依赖并继续原 workflow。修复、合并与后续执行仍遵循各项目流程及用户授权。
这是已有 CLI 会话之间的通信，不是向正在执行的一次性 runner 任务注入新指令。

### 大型 feature 开发的自动化 AI Coding 工程控制框架

先准备架构设计和实施总控计划，完成 preflight，再由 `phaseflow` 推进 phase / work unit，按 `gateflow` 的固定 gate 顺序执行。
目标确认后，简单计划由总控核对，重要决策执行 Planreview。默认一个 slice 实施与验证，对最终组合版本做一轮完整代码审核，
必要修复及受影响面复审后按需提交、创建 draft PR，由总控核对交付并完成 final closeout。

每一步留下可追踪的 artifact、审核裁决、剩余风险及下一步入口，让长流程在明确边界内推进。
PR 合并由用户手工完成；跨会话继续时，可依据总控文档与已验收成果恢复进度。
merge、approve、mark ready for review、request reviewers、delete branch、对外 comment、创建或修改外部 issue 仍需用户明确授权。

本仓库是 `skills/` 下所有 skill、`scripts/agent-tools.zsh` 中 Agent 启动函数，以及 `scripts/*-agent-run` 子 Agent
调用入口的真源。本地运行时文件只是安装目标，不应作为编辑源；应先修改并验证仓库真源，再同步到本地运行环境。

## 包含的 Skills

| Skill | 职责 |
| --- | --- |
| `gateflow` | 定义单个 work unit 的 gated workflow：preflight、goal confirmation、最小必要计划与适用计划审核、实现/验证、一轮完整代码审核、必要修复、draft PR 交付核对和 final closeout。它不定义项目级总控文档，也不定义多 Agent 路由。 |
| `phaseflow` | 项目分步总控。读取 `design_doc` 和 `control_doc`，识别当前 `phase = work unit`，完成 preflight / goal confirmation、简单计划及 PR 交付核对，派发 Agent 做 plan / implementation / fix 和适用独立 review，裁决结果，更新 `control_doc`，并 reconcile residual risks。 |
| `planreview` | 对重要契约、架构、迁移或状态机决策，以及显式指定的 plan 做 adversarial review。 |
| `deepreview` | 需要严格 review 当前 workspace 改动、GitHub PR 或整个仓库。 |
| `tmux-agents` | 只定义 tmux 通信：Agent CLI 类型、`/skill` vs `$skill`、pane discovery、clear/session 规则、`tmux-cli send/wait_idle/capture` 和发送安全规则。它不分配角色。 |
| `sub-agents` | 通过 runner 子进程启动外部 Claude Code 或 Codex 子 Agent，校验结构化结果，并支持隔离的并行派发；它不分配角色。 |

## 使用演示

```text
按照 $phaseflow 推进，设计真源在 docs/host/design.md，总控文档是 docs/host/issues-implementation-control.md。
严格遵循 AGENTS.md 的约束。
```

等价的显式参数写法：

```text
$phaseflow design_doc=docs/host/design.md control_doc=docs/host/issues-implementation-control.md
```

## 核心工作流

典型使用方式是：

1. 先写好设计真源文档，例如 `docs/design.md` 或 `docs/host/design.md`。
2. 再写好实施总控文档，例如 `docs/implementation-control.md`，记录 phases/work units、状态、验证要求、artifacts、residual risks 和 next entry point。
3. 使用 `phaseflow` 读取这两个文档，识别当前 `phase = work unit`，并和用户完成 preflight 与 goal confirmation。
4. `phaseflow` 读取 Gateflow 的 `Gate Order`，派发 plan，亲自核对简单计划；重要契约、架构、迁移或状态机决策，以及显式审核要求，派发 Planreview。
5. 每个 Agent 返回后，`phaseflow` 读取 artifact、裁决 findings、更新 `control_doc`，再进入下一个 gate。
6. 派发实现/验证，默认一个 slice。所有必要 slices 完成后，对最终组合版本做一轮完整 Deepreview，包含整体目标覆盖和 slice 交互；accepted findings 实际修复并做受影响面复审，通过后记录 readiness 和 residual-risk owner。
7. 按需提交、push 并创建 draft PR；总控核对实际 PR 身份、head/base 版本、完整 diff 与已审版本对应关系、title/body、必要 CI 和最终 push，再进入 `draft-PR-pass`。内容或 base/diff 变化须补受影响面审核/验证，相同内容不重复完整审核。
8. final closeout 随后记录变更内容、验证结果、文档更新、finding 状态、剩余风险和 owner、draft PR URL，以及 next entry point。
9. 如果 work unit 是 issue，draft PR body 应关联 issue；final closeout 应确认 issue closeout comment 和 merge 后关闭预期。
10. final closeout 通过后，用户手工 merge PR，拉取最新目标 base branch，按需 `/clear`，再从 `control_doc` 的 next entry point 恢复 `phaseflow`。

计划达到足以指导正确实现即可，Agent 在已确认范围内决定局部实现。记录可同文件维护或引用已有证据，不要求每个 gate
独立 artifact 或 commit。

## 环境要求

- Codex CLI、Claude Code，或其它支持本地 skill-style instruction files 的 Agent runtime。
- 如果要运行本仓库自带的 skill 校验脚本，需要 Python 3.11+。
- 如果使用 `tmux-agents` 做多 Agent handoff，需要安装 `tmux` 和 `tmux-cli`。

如果要使用后文几个启动 Agent 的 zsh 函数中的 `tmux select-pane -T` 自动设置 pane title，需要先在 `~/.tmux.conf` 中固定 pane 标题，避免运行中的程序覆盖：

```tmux
# 固定 pane 标题，不让运行的程序覆盖
set -gw allow-set-title off
```

`tmux-cli` 属于 `claude-code-tools` 包。安装或更新到固定的官方发行版：

```bash
uv tool install --force 'claude-code-tools==1.29.1'
```

此命令会更新整个 `claude-code-tools` 包，不只更新 `tmux-cli`。[v1.29.1](https://github.com/pchalasani/claude-code-tools/releases/tag/v1.29.1) 已通过合入上游的 [PR #213](https://github.com/pchalasani/claude-code-tools/pull/213) 包含我们的 [PR #212](https://github.com/pchalasani/claude-code-tools/pull/212)：remote status/preflight 不再创建托管 session，缓存的 window target 会在复用前重新验证。无需再依赖 fork。本项目的 skills 另用已有的 `./scripts/sync-skills.sh` 同步。

官方文档：

- `tmux-cli`: https://pchalasani.github.io/claude-code-tools/tools/tmux-cli/
- `claude-code-tools` 安装说明: https://pchalasani.github.io/claude-code-tools/getting-started/

## 安装

macOS 上需已有 Git、Codex CLI、Claude Code、Python 3.11+、jq、uv、tmux、rsync、zsh 和 curl。下载并运行安装入口：

```bash
curl -fsSL https://raw.githubusercontent.com/noho/code-is-cheap/main/install.sh -o install-code-is-cheap.sh
bash install-code-is-cheap.sh
```

下载成功后再执行第二条命令。已有 checkout 可直接运行 `bash ./install.sh`。
下载的安装脚本将仓库克隆到 `~/.local/share/code-is-cheap`；重复运行时对干净的 `main` checkout 执行 fast-forward 更新。可通过 `AGENT_INSTALL_DIR` 指定其它目录。

脚本创建含 PyYAML 的独立校验环境（以后手动 sync 也会自动复用），安装 `claude-code-tools==1.29.1`，将 skills 同步到 `~/.codex/skills` 和 `~/.claude/skills`，部署启动函数、runner、模型卡，向 `~/.zshrc` 添加 PATH 和 launcher 加载入口，并安装 launchd shim 服务。`bash install.sh --no-service` 可跳过服务安装。脚本不安装 Codex/Claude CLI、不登录账号、不创建可选 business 账号 home，也不启动本地模型服务。

已有私有连接 JSON、Codex 登录和其它本机 Codex 设置会保留。安装后重新打开 Agent 会话以加载 skills，并运行 `source ~/.zshrc` 在当前 shell 加载启动函数。

### 私有连接配置：default 和 override

`~/.config/agent-tools/endpoints.json` 统一保存每个 provider/runtime 的上游 URL、模型 ID 和 API key，权限必须为 `600`。安装器仅在文件不存在时创建；sync 不创建或修改用户文件。`config/endpoints.example.json` 是单独部署的程序默认资源，不含云端凭据。初始 URL 和模型选择保持当前值；以下示例不会自动选择新云商。

- `default`：你的基线连接，已有文件必须包含此对象。provider/runtime 名称必须受支持，每个 runtime 必须恰好包含 `base_url`、`upstream_model`、`api_key`。
- `override`：可选的覆盖连接，沿用 provider/runtime 层级。覆盖必须**同时填写这三个字段**，避免新云商沿用旧云商的 key。其他 runtime/provider 保持默认连接；删除该 runtime 的 override 即可恢复。
- 缺少文件或某个 runtime 连接时使用程序默认资源。云端启动仍需要有效连接中的非空 key，不能从备份节点或继承的环境变量补充。空字符串不表示继承。

临时停用单个 runtime 的覆盖时，可将 `override.ds-flash.codex` 改名为 `override.ds-flash.codex-bak` 或任意其他未识别的 runtime 名称，例如 `override.ds-flash.saved`。同级 `claude` 和其他 provider 的覆盖保持激活。停用某个 provider 的覆盖时，可将 `override.ds-flash` 改名为未识别的名称，例如 `override.ds-flash-bak` 或 `override.overrideds-flash-bak`。停用全部覆盖时，将根节点 `override` 改名为 `overridexxx`，保留 `default`。空的 override-provider 对象（`"ds-flash": {}`）或所有 runtime 名称均未识别的对象都不提供任何覆盖。受影响的连接回退到你完整的 default 连接三元组，缺少的连接再使用程序默认资源。恢复精确的受识别名称后，会重新校验并启用保存的覆盖；helper 不修改私有文件。

只有精确命名的根节点 `override` 及其下被已安装 factory 识别的精确 provider/runtime 名称会激活，不使用特殊备份后缀或名称归一化。未知私有根字段、override-provider 和 override-runtime 名称会在检查其值之前被忽略，但整个文件仍须是有效 JSON，包括备份内部在内的重复字段也会被拒绝。受识别的 override provider 必须是对象，不能是 null、标量或列表。`default` 仍严格校验：未知 provider/runtime 和空 provider 对象均会报错。所有激活的 override 仍严格校验连接字段：字段缺失或多余、无效 URL/模型/key、空白云端 override key，即使查询无关连接也会报错。修改激活连接三元组内的字段名称仍会校验失败。文件必须是当前用户拥有、权限为 `600` 的普通文件，不能是符号链接。程序默认资源仍严格校验结构，且不得包含云端凭据。

例如在 `override` 中添加以下连接，仅切换 `ds-flash_codex`（填入网关实际 URL/模型/key）：

```json
{
  "default": {},
  "override": {
    "ds-flash": {
      "codex": {
        "base_url": "https://gateway.example/custom/v1",
        "upstream_model": "gateway/model-id",
        "api_key": "YOUR_GATEWAY_KEY"
      }
    }
  }
}
```

编辑初始化文件时保留已有的 `default`，只添加 override；上面的空块仅为缩短示例。Codex 的 `base_url` 是完整 Responses API base URL，不含 `/responses`；Claude 使用 Anthropic API base URL，不含 `/v1/messages`，准确传递 `upstream_model`，不额外追加 `[1m]`。两者沿用现有 Bearer 鉴权方式。不转换 API 协议，网关必须支持对应 API/模型以及流式响应、工具调用。保留现有 profile 的上下文限制和 catalog 元数据，切换前需确认网关支持这些能力。

Claude 启动时读取一份连接快照，只将选定 token 交给 Claude 进程，不放进 argv/settings JSON。Codex 云端保留逻辑模型卡/catalog 和 loopback provider ID；shim 每次请求读取一致的 URL/模型/key 快照，将普通逻辑模型和 `codex-auto-review` 映射到配置的上游模型，并自行添加选定 Bearer token。普通流式请求不会被缓冲，guardian 的重试行为单独保留。拒绝上游重定向，避免向其他地址转发 key。云端连接修改后下一次请求直接生效，无需 sync 或重启服务，App 会话也适用。

`local.codex` 仍直接连接且不鉴权，`api_key` 必须为空；修改 URL 后需运行 `sync-codex-agent.sh`，模型在 CLI/App 启动时应用。`local.claude` 和其它 Claude 连接一样使用配置中的 URL/模型/token，初始 token 为 `local`。GPT/business 继续使用原有账号登录和模型卡。网关 API key 不写入 provider registry、catalog、App 配置或服务 plist；账号登录仍使用 Codex 的 auth 文件。仍清理继承的凭据环境变量；`600` 权限不隔离同用户运行的其他进程对文件的访问。

## 可选任务禁读边界（macOS）

**平台限制：`agent-sandbox --deny-list` 当前仅支持 macOS**，通过 srt 使用 Seatbelt。
本项目尚未实现和验证 Linux 封装，Windows 不支持。非 macOS 系统会明确报错，不会退回无沙箱运行。
`--full-access` 使用 runtime 原生参数，不依赖 Seatbelt。

默认 runner/launcher 行为不变。显式 `--full-access`：Codex 关闭内层沙箱和审批；Claude 使用
`bypassPermissions` 并关闭内层沙箱。单独使用该参数没有读取隔离。

普通安装之后，需要禁读边界时再安装可选依赖（Node >=22.12、npm）：

```bash
install-agent-sandbox.sh
```

安装固定版本 Anthropic 的 Apache-2.0 `@anthropic-ai/sandbox-runtime` 0.0.79。普通安装/sync 不要求或安装 srt。
封装要求安装的 **Node 包 CLI**，不接受独立编译版 srt；sync 同时部署相邻的 `agent-sandbox-launch.mjs`。
适配器将同一禁令中同父目录的字面路径/子树条件合并为有长度上限的精确正则并集，避免 Seatbelt 字面量数据表超限；
保留所有路径、子树范围、规则顺序和操作。压缩时原策略保存在 `seatbelt.source.sb`，实际策略保存为
`seatbelt.sb` 并通过 `sandbox-exec -f` 加载，避免大策略嵌入启动参数导致 `spawn E2BIG`。
原路径禁止写入/移动，但运行期硬链接别名仍能改写留存文件，不会改变已加载的内核策略。
适配器在启动子进程前把 `profile_sha256` / `source_sha256` 打到封装 stderr；调用方须通过可信父进程 pipe 收集该流，
审计时先比对留存文件哈希。仅凭 Agent 可修改的日志或留存文件不能证明完整性。
只认封装 stderr 中 runner 启动前的第一条 `seatbelt_profile=` 适配器记录；后续重复行可能由子进程伪造，
不得覆盖首条记录或采用 last-wins 解析。未压缩时只留存 `seatbelt.sb`，两项哈希相同。
预检和启动共用不派生子进程的安装结构/模块检查，预检先验证结构再执行 `srt --version`；不支持的 CLI 启动结构明确失败。macOS 原生策略编译器
仍有容量限制；编译失败时在验证及 runner 启动前停止，不删减禁读项或扩大权限。
两个封装命令由 `scripts/sync-agent-tools.sh` 部署。已测试 macOS、Codex 0.161.0、Claude Code 2.1.294。

`denied.json` 为非空 JSON 数组，每项是**绝对且已存在**的禁读文件/目录，字面路径，不是 glob；目录递归禁止。
调用方自行列出业务报告、历史日志及已知副本；未列出的副本仍可读。

```bash
agent-sandbox --cwd /path/to/workspace --deny-list /path/to/denied.json -- \
  codex-agent-run --provider mimo --prompt-file /path/to/task.md \
  --output /path/to/new-events.jsonl --stderr /path/to/new-stderr
# claude-agent-run 使用相同封装。
```

有效软链接目标保留 stdlib strict canonicalization。扫描禁读目录发现失效链接时，仅确证 ENOENT 后使用
`os.path.realpath(strict=os.path.ALLOW_MISSING)`；该分支缺少此能力会带定位 setup failure，不安装或 fallback，
Python 3.11+ 下限不变。missing-aware canonicalization 可在 `..` 后重入已存在目标，setup 逐条报告并保守禁读该目标，
不证明原始链接当前可达；后续非 ENOENT 错误带声明、链接及原始 target 上下文失败，不承诺 stdlib 与 kernel open 的错误优先级相同。

最终缺失目标仍保留为禁读/禁写路径，同时递归禁止其最近已存在目录祖先的全部读写。祖先进入相同软链接扩展扫描；
其中的二级失效链接可级联添加其它子树的祖先，每条扩展报告来源和发现目录。这可能连带禁止 sibling、扩大扫描或与必需输入冲突；
root 祖先、不可读/不支持目标、扫描失败及输入冲突均停止 setup，不放宽策略。验证先对每个已存在边界 query 并实际确认拒读，
仅有已实测祖先覆盖的登记缺失目标才可容忍 ENOENT；ENOENT 或 query=1 单独均不是隔离证明。允许 probe 的实际读写仍须成功才启动固定 runner。

封装隐含 `--full-access --no-persist`，启动前固定策略，在 Seatbelt 内确认禁读路径确实被拒绝，再启动 runner。
不支持的参数、直接声明的缺失路径、版本不匹配、已有硬链接、无法保留原写边界的配置均明确失败，不退回无隔离运行。
写入保留原 runtime 的保守子集：Codex read-only 不开放 cwd 写入；workspace-write 保留 cwd 并保护
`.git/.codex/.agents/.aws`，不携带额外 writable roots。Claude 保留 cwd 和各设置层中绝对路径或 `~/` 开头的字面 sandbox `denyWrite`。
仅另加调用方指定的输出**文件**与独立运行状态目录，不开放输出文件的整个父目录。Codex permission profiles、
项目层配置，以及 Claude 自定义读、glob/相对写路径或工具 deny 规则暂不支持。原 Codex `.rules` 复制到独立 home 并禁止修改。禁读路径同时不可写。
运行时必需的凭据/配置文件（包括 endpoints JSON、所选 Codex auth）必须可读；列入禁读时 setup 停止。封装不隔离 Agent 与工具对凭据的访问。

隔离 Codex HTTPS 在 `--check` 与启动时共用显式 CA 准备。非空 `CODEX_CA_CERTIFICATE` 优先于非空
`SSL_CERT_FILE`；恰好空字符串会继续回退，空白字符仍是字面路径（此 CA 行为已在 Codex 0.162.1 验证）。
两者都无效时选择 `/etc/ssl/cert.pem`。只检查所选输入；显式输入有误时带 source/path 定位失败，
不会改用低优先级 bundle。相对路径基于 `--cwd`，导出的字面 `~` 不展开；子进程接收 canonical 路径，父环境不变。

输入必须是获准可读的普通 PEM 文件，含至少一个 `CERTIFICATE` 和/或 `TRUSTED CERTIFICATE`。
每个识别到的证书都检查语法，畸形伴随证书会失败；trusted 标签仅在内存中规范化用于验证，
原生 Codex 仍读取原文件及 AUX 数据。忽略 `X509 CRL`，不做吊销验证。
忽略证书块之外的注释和非证书条目（包括 CSR），这些内容不计为证书。
setup 不证明 endpoint trust、内核隔离或全部原生 parser/算法兼容性，也不增加文件权限或网络访问。

公共系统 PEM 可能不含仅安装在 macOS keychain 的企业根；调用方须提供包含所需根的获准显式 PEM。
封装不导出 keychain 根、不授予 trustd、不关闭 TLS 验证。可在上述封装命令前导出绝对路径：

```bash
export CODEX_CA_CERTIFICATE=/absolute/path/to/permitted-ca.pem
```

原任务恢复及大禁读名单验证由调用方在部署后负责；本次工作不 merge 或 sync 到在线安装。

隔离运行使用全新 runtime 状态，关闭宿主 MCP/hooks/plugins/浏览器集成，禁止 Apple Events/Unix sockets，
网络限于所选模型路由；Claude 只启用 Bash/Read/Write/Edit/Glob/Grep，Codex 保留本地原生工具。
可用 `--allow-domain host[:port]` 额外开放调用方授权的网络目的地。权限不足应报告缺项，不自动放宽。
每次策略/状态路径打印在 stderr 并保留在临时目录。运行期间不能由未隔离进程替换禁读路径或另造可读副本。
路径禁令不识别其它位置的相同内容，也不隔离 prompt 已提供的信息；runtime 升级后应重测读取通道。

preflight 可加 `--deny-list /absolute/denied.json` 生成完整封装命令；`--check` 仅预检，不证明内核隔离。
封装必须从**总控**沙箱外派发：Codex 用 `exec_command(require_escalated)`；Claude 在自己的
`sandbox.excludedCommands` 加入 `agent-sandbox`，以独立裸命令调用。保留生命周期及调用方显式选择的结果检查。
一次隔离调用不支持 resume、动态投递或原生参数透传。必须恰好一个非空 `--prompt` 或普通 `--prompt-file`；
关闭 stdin，并将准备好的 prompt 复制到受写保护的运行状态。验证同时查询 Seatbelt 权限和实际文件读取；普通 Unix 权限错误不足以证明隔离。

## 准备 Agent 环境

如果已成功运行 `install.sh`，可跳过本节的手动部署步骤：安装器已部署 launcher/runner、模型卡并配置 shell 加载入口。仍需按上一节填写 API key 和可选的自定义 URL，并执行 `source ~/.zshrc`（或打开新 shell）以加载启动函数；另需重新打开 Agent 会话以加载 skills。使用可选的 `business` 或本地模型时，仍需自行准备对应账号 home 或本地服务。下面的步骤用于手动安装或后续更新。

受版本控制的真源是 `scripts/agent-tools.zsh`、`scripts/claude-agent-run` 和 `scripts/codex-agent-run`，安装副本位于
`~/.config/zsh` 和 `~/.local/bin`。应修改仓库真源并重新同步，不要直接编辑安装副本。
`sync-agent-tools.sh` 还会把 URL helper、默认 URL 资源和手动旧版恢复工具 `repair-codex-reasoning-history.py` 安装到 `~/.local/bin`。

前置要求：

- `zsh`、`claude`、`codex`、`jq` 和 `curl` 已在 `PATH` 中。
- URL 读取、连接 helper/runner 和独立的手动旧版恢复工具需要 `python3` 3.11 或更新版本；`agent-endpoint.py` 应与其它 runner 一起在 `PATH` 中。
- `~/.local/bin` 已在 `PATH` 中，可以直接调用子 Agent runner。
- 私有连接 JSON 中选定云端 runtime 的 `api_key` 已填入非空值。
- 每个 Codex profile 的模型卡已部署为可读的 `~/.codex/<agent-id>.config.toml`（`business` 例外：`~/.codex-agent/business/config.toml`）。
- `local` 服务地址由 `~/.config/agent-tools/endpoints.json` 中 `default` 或 `override` 下的 `local.claude.base_url`、`local.codex.base_url` 决定，默认 `http://127.0.0.1:8080`；健康检查使用对应 runtime 的 URL 加 `/health`（Codex 先去掉末尾 `/v1`），因此 Claude/Codex 可配置不同端口。

凭据只保存在私有连接 JSON 中，不入仓库。

安装或更新启动函数和子 Agent runner：

```bash
./scripts/sync-agent-tools.sh
```

在 `~/.zshrc` 中加载：

```zsh
[[ -r "$HOME/.config/zsh/agent-tools.zsh" ]] && source "$HOME/.config/zsh/agent-tools.zsh"
```

同步后重新加载当前 shell：

```bash
source ~/.zshrc
```

可用启动命令：

| Runtime | Agent IDs | 命令 |
| --- | --- | --- |
| Claude Code | `ds-flash`、`mimo`、`mimo-fast`、`mimo-flash`、`qwen`、`kimi`、`glm`、`glm-flash`、`local`、`hy` | `<agent-id>_claude [args...]` |
| Codex CLI | `ds-flash`、`mimo`、`mimo-fast`、`mimo-flash`、`qwen`、`kimi`、`glm`、`glm-flash`、`hy`、`local`、`gpt-6-astra`、`gpt-6-astra-x`、`gpt-6-astra-max`、`gpt-6-sol`、`gpt-6-sol-x`、`gpt-6-sol-max`、`gpt-6-luna`、`business` | `<agent-id>_codex [args...]` |
| Codex app | 与 Codex CLI 相同 | `<agent-id>_codex_app [workspace]` |

CLI 启动命令可传入 `--title`，设置 `ClaudeAgent-DS-Flash`、`CodexAgent-GPT-6-Astra` 这类稳定的 tmux pane title。
`hy` 的 Claude 与 Codex 均选择 `hy4`；提供 `hy_codex`、`hy_codex_app` 与 runner 别名 `hunyuan`。Codex 工厂默认直连 `https://tokenhub.tencentmaas.com/v1`，shim 端口 8796。2026-11-05 的一次有界 native workflow 完成实际工具续接和自动安全审核；这仅是运行时集成证据，不保证可用率或模型能力。Hy 使用仓库独立编写的纯文本兼容元数据、`high` effort 和常规 1048576 / 786432 上下文及压缩配置，未实测这些容量。独立 bundled guardian 保留 native 安全元数据，沿用 direct/non-Lite 传输。

下列 Token Plan override 替换完整 URL/model/key 元组，密钥均为占位符。当前测试 key 返回 HTTP 403 / `403001`（套餐禁用或无调用权限），这是账号权限阻塞，不能解释为 Hy 不兼容。仅使用有权限的账号启用。更新两处 endpoint factory 后才能激活 `override.hy.codex`。支持 runtime 改名停用的 helper 会忽略已安装 factory 中不存在的 runtime override；历史 helper 则可能拒绝整个文件。`default` 中未知 runtime 仍会报错。私有配置不得进入 Git。

```json
{"override":{"hy":{
  "claude":{"base_url":"https://tokenhub.tencentmaas.com/plan/anthropic","upstream_model":"hy4","api_key":"YOUR_TOKEN_PLAN_KEY"},
  "codex":{"base_url":"https://tokenhub.tencentmaas.com/plan/v3","upstream_model":"hy4","api_key":"YOUR_TOKEN_PLAN_KEY"}
}}}
```

app 启动命令会使用所选 profile 和可选 workspace 打开一个新的 Codex app 实例。桌面 app 只读 `$CODEX_HOME/config.toml`
全文（没有 `-p` 叠加），所以每个受管 app 实例在自己的 user-data 目录里拿一份**合成 home**（共享 base ＋ 所选模型卡，
`compose-codex-app-config.py` 每次启动幂等合成）——启动即所选模型；各 app home 的会话记录彼此隔离。
CLI 会话若要选择另一模型，请在共享 home 中显式指定目标 profile（
`gpt-6-sol_codex resume <session-id>` 或 `codex resume -p gpt-6-sol <session-id>`）。兼容性由 Codex 判断：
同 provider 换模型可能出现警告；不同 provider 可能使原会话只读，并提供在新对话中继续的入口（见下文）。

```bash
mimo_claude --title
gpt-6-astra_codex --title
gpt-6-astra-x_codex --title
gpt-6-astra-x_codex app /path/to/workspace
gpt-6-astra-x_codex_app /path/to/workspace
business_codex_app /path/to/workspace
```

`tmux-agents` 会发现这些 pane title，但不会分配角色。请在当前用户 prompt 中写清期望分工。

总控非交互调用子 Agent 时，使用已安装的 runner 命令：

```bash
claude-agent-run --provider mimo --cwd /path/to/workspace --prompt-file task.md
codex-agent-run --provider gpt-6-astra --cwd /path/to/workspace --prompt-file task.md
codex-agent-run --provider gpt-6-astra-x --cwd /path/to/workspace --prompt-file task.md
```

runner 可通过 `--prompt`、`--prompt-file`、位置参数或 stdin 接收 prompt，并支持输出文件、临时或持久 session，
以及 provider-specific passthrough arguments。完整接口使用 `--help` 查看。总控必须显式传入 `--cwd`，避免子 Agent
意外继承总控的 workspace。

普通任务直接调用 runner。它自动生成私有日志和 Claude instance；不要求单独预检、label、固定 prompt 标题、
子 Agent 自报 runtime/provider/model、canary 或额外报告。任务须交接必要上下文：子 Agent 不继承总控对话。
要求交付文件时，让最终答复给出路径，按任务需要使用/核对文件；修改既有源码无需另写一份描述修改的报告。

`sub-agent-preflight` 是可选的提前 setup 检查和命令生成器：

```bash
sub-agent-preflight --runtime codex --provider gpt-6-sol --cwd /path/to/workspace --task-file task.md
```

只检查所选 runner/provider/launcher/profile，生成私有目录及自动 label，复制任务并追加简短的最终答复要求。
`--task` / `--task-file` / `--prompt-file` 必须且只能给一种非空白任务，不要求固定小节。成功输出 `key=value` 和
已 quoting 的命令，失败不输出命令。`--label` 可选；仅需要文件读取证明时加 `--canary`，默认不创建 proof 文件或参数。
token 不打印，也不写入 prompt。

### Runner 结果

实际 runtime 退出后，runner stdout 返回一个 schema-v2 JSON 汇总：`final_answer`、诊断、完整日志路径和统计。
`--output` / `--stderr` 保存原始日志，即使 stdout 返回汇总也保留；未指定时创建私有文件。显式 `-` 目标（`--output` / `--stderr` / Codex `--last-message`）
需要 `--detail`，汇总模式明确拒绝，不静默替换。Claude 内部用 stream-json。
等待托管进程句柄返回退出码，再使用最终答复和任务产物；没有增加中途指令通道或自动完成通知。

```bash
codex-agent-run --provider mimo --cwd /path/to/workspace --prompt-file task.md
claude-agent-run --provider ds-flash --cwd /path/to/workspace --prompt-file task.md
# 原始输出和原有重定向行为：
codex-agent-run --provider mimo --cwd /path/to/workspace --prompt-file task.md --detail
```

外层退出码就是实际原生 CLI 退出码，包括非零 1/2/126/127。说明缺少输入、环境阻碍或未能完成工作的 final 是正常答复。
缺失产物、canary 不匹配、工具错误、日志损坏或协议诊断都不改写已知原生退出码。调用方按自己的用户/项目授权与路由
决定任务验收和后续交互；没有自动重试或换 provider。保留各次尝试/日志、测量样本归属与指定并发度，不能用重试替换失败样本。

汇总 schema version **2**：

| 字段 | 含义 |
| --- | --- |
| `schema_version`, `source`, `runtime`, `provider` | `2`、`subagent_report` 和所选 runtime/provider。 |
| `runtime_exit_code`, `final_answer` | 实际原生退出码和**完整、不截断**的原生 final，保留 Unicode 与所有空白。 |
| `session_id`, `terminal` | 原生身份与终态 type/subtype，缺失或冲突时为 null。 |
| `wall_clock_seconds`, `usage`, `runtime_metrics` | 启动到调用收集器的实测时间、单一终态原始用量和 Claude 时长/费用/modelUsage；缺失为 null/空对象，真实零值保留，不累加流式片段。 |
| `logs` | 绝对 `output`、`stderr`、可选 `last_message` 路径；部分文本仍在原始日志中。 |
| `diagnostics` | 单一 `{message, path, line}` 事实列表。warning 原文带来源保留，不判断措辞、严重性或是否恢复。 |
| `checks` | `artifacts: [{path, exists, regular_file}]`；未请求 canary 时为 null，否则为 `{proof_observed, proof_matches_expected, read_candidate_observed}`，无可比较证明时匹配为 null。 |

v1 迁移：移除对 `agent_status`、`validation_status`、`result_status`、`runner_exit_code`、`final_answer_chars`、
`final_answer_truncated`、三类诊断及其计数/截断字段、工具/事件汇总的依赖；使用原生退出、完整 final、来源诊断与 `checks`。
检查缺项不再产生拒收退出，也没有替代 wrapper verdict。收集器成功序列化观察结果时退出 0，即使日志缺失/损坏；
收集器进程退出码不是业务验收。

Codex 最后一条 completed agent message 拥有 final；Claude 仅由唯一根 `result` 字符串提供 final，中间 assistant 或嵌套
result 不回填。缺失、非文本、歧义 final 为 null；实测空字符串保持空字符串。无关损坏帧或原生负面元数据不会抹去
可归属 final。缺失/冲突身份、终态只产生诊断；统计仅来自无歧义终态。只有显式持久化会话才能 resume，ID 不代表会话已保存。

原生 exec 前的参数、输入、路径、依赖或 launcher 错误退出 2，stderr 给出原因及已分配日志路径，不伪造原生 report。
原生退出后若封装无法运行收集器、序列化或写出主结果，stderr 记录实际交付错误、已知原生退出码与日志路径；
原生 0 时外层退出 1，原生非零时保留原码。Codex 附加 `--last-message` 缺失、复制/竞争/清理失败均保留原生退出码，
保留可用临时源并报告位置，不覆盖既有目标。`--detail` 返回原始输出，跳过收集及可选收尾检查，原生退出语义相同。

`AGENT_TOOLS_FILE` 继续支持自定义 launcher，但必须显式实现 **pre-exec-error-v1**：source 后
`_agent_tools_runner_contract` 仅在终端 helper 支持契约时输出恰好 `pre-exec-error-v1` 并退出 0。
runner 的 `AGENT_RUN_ERROR_FD` 指向仅报告 exec 前错误的内部 pipe；exec 前返回/失败必须写入，成功 exec 时以 CLOEXEC
关闭，并从原生环境移除此变量。没有成功握手或退出后协议。仓库 launcher 使用 `agent-endpoint.py` 做终端 exec；
能力检查在启动前发现 helper 版本偏差。不支持/过时 launcher 在启动前按 setup 失败处理；普通无内部描述符的交互调用保持原行为。
请一起同步 runner、launcher、helper；不从缺失事件、特殊数字或 warning 措辞推测原生归属。

可选重复 `--artifact /path/to/new-file` 在派发前要求新路径；收尾存在性、类型、硬链接/日志别名及读取错误仅为观察，
不证明来源或内容。未声明时不自动从 final 提取路径。成对 `--canary-file` / `--canary-expected` 启动前检查可读非空普通输入
和有效 token；preflight `--canary` 会设置它们。证明为不缩进、不在代码块内的独立 `CANARY=<token>` 行；
匹配与候选读取轨迹不证明整项任务正确，诊断消息保留二级 proof 行号。`agent-sandbox` 下仍遵守既有边界。
`--detail` 可用 text 或 Claude json。参阅[高级调用参考](skills/sub-agents/references/advanced.md)。

## Codex Agent 配置（xx_codex）

所有受管 profile 共享一个 Codex home（`~/.codex`，Codex 默认 home，**必须是真目录**——桌面 app 沙箱拒绝路径中的 symlink 成分）：base `config.toml` 承载政策与
机器本地运行时状态，每个 profile 是一张模型卡 `~/.codex/<agent-id>.config.toml`，launcher 用
`codex -p <agent-id>` 叠加加载——启动选卡即选择模型，会话池共享。通过目标模型请求 Codex 恢复会话时，用对应的
launcher（如 `gpt-6-sol_codex resume <session-id>`），或显式传入 profile（如
`codex resume -p gpt-6-sol <session-id>`）。单独执行 `codex resume <session-id>` 可能恢复会话上次选中的模型，
不能保证使用 base config 的默认模型。十个第三方 profile（`ds-flash`、`glm`、`glm-flash`、`kimi`、
`mimo`、`mimo-fast`、`mimo-flash`、`qwen`、`hy`、`local`）与七个订阅制 OpenAI profile（`gpt-6-astra`、`gpt-6-astra-x`、`gpt-6-astra-max`、`gpt-6-sol`、`gpt-6-sol-x`、`gpt-6-sol-max`、`gpt-6-luna`）已在仓库
`codex-agent/profiles/` 下维护；`business` 保留独立的 CODEX_HOME（`~/.codex-agent/business`，另一账号）。
共享 base 配置仍归本机管理，只有带标记的 provider 注册块由本仓库管理。

launcher 把原生 `resume` 及其参数交给 Codex，包括会话名称、选择器选项、`--help`、`--last` 和 prompt。
开头的 `--resume` 与 `--resume=<session-id>` 仅分别规范化为 `resume` 与 `resume <session-id>`，
其余参数的顺序和边界保持不变。不带 ID 的 `--resume` 打开原生选择器；`--resume=` 把空会话参数交给 Codex 解释。
launcher 恢复会话时不会检查或修复 rollout。`gpt_codex` 通过 `gpt-6-sol_codex` 提供相同的参数转发。

provider 兼容性和后续续接由 Codex 负责。官方[启动/恢复文档](https://learn.chatgpt.com/docs/app-server#start-or-resume-a-thread)
说明 provider 不匹配时会拒绝向原线程输入；同 provider 切换模型则有单独的警告。
用户在当前 TUI 中观察到：provider 不匹配会让原会话变为只读，并提供按 `c` 在新对话中继续的入口；
新对话收到读取已保存对话记录并继续工作的 prompt。请按已安装 Codex 版本提供的操作继续，界面文字和快捷键可能变化。
这不保证转移全部内部状态或工具执行，观察到的 TUI 流程也不一定等同于 app-server 的 `thread/fork`。
launcher 将流程交给 Codex，不改写会话元数据，也不自动选择续接操作。

`gpt-6-astra` 留给重要、低频的任务；`gpt-6-sol` 用于日常消耗量大的任务，`gpt-6-luna` 负责低成本的批量任务。
Astra 和 Sol 均提供三档 provider：默认名称使用 high，`-x` 使用 xhigh，`-max` 使用 max。
Astra 三档上游均为 `gpt-6-astra`，Sol 三档上游均为 `gpt-6.1-sol`；Luna 保持 max。
这些订阅制 provider 使用账号登录，不需要 API key 或 shim。
`sync-codex-agent.sh` 将 Sol 默认卡的模型和推理等级（GPT-6.1 Sol / high）同步到 `business` 的独立
CODEX_HOME，只更新这两个顶层键，保留账号及其他本机设置。`gpt_codex` 仍选择 `gpt-6-sol`，
runner 的 `sol` 和 `astra` 别名仍选择各自默认 high provider。

`gpt-6-astra-x` 替代 `gpt-6-astra-xhigh`，旧名称不再是受支持的 runner provider 或受管 launcher。
同步保留额外的已安装模型卡，因此 native Codex 仍可能直接选用旧卡；旧卡存在不代表 runner 支持旧 provider。
已有 App data、session 和个人设置均保留。已加载的旧函数需打开新 shell 清除，或先显式执行
`unfunction gpt-6-astra-xhigh_codex gpt-6-astra-xhigh_codex_app`，再 `source ~/.zshrc` 加载新函数；
仅 source 不会删除旧函数。重新打开 Agent 会话以加载更新后的 skills。

| Profile | 模型 | 网关 | shim 端口 | 网关修复 |
| --- | --- | --- | --- | --- |
| `ds-flash` | `deepseek-flash` | api.deepseek.com | 8788 | 改模型名 + 原生 Agent 消息适配 + 目录补丁 |
| `glm` | `glm-5.3` | open.bigmodel.cn | 8789 | 改模型名 + 目录补丁 |
| `glm-flash` | `glm-5.3-flash` | open.bigmodel.cn | 8795 | 改模型名 + 目录补丁 |
| `kimi` | `k3` | api.kimi.com | 8790 | + 目录补丁 |
| `mimo` | `mimo-v2.6-pro` | token-plan-cn.xiaomimimo.com | 8791 | + 目录补丁 + `json_object` 降级 |
| `mimo-fast` | `mimo-v2.6-pro-ultraspeed` | api.xiaomimimo.com | 8794 | + 目录补丁 + `json_object` 降级 |
| `mimo-flash` | `mimo-v2.6-flash` | token-plan-cn.xiaomimimo.com | 8793 | + 目录补丁 + `json_object` 降级 |
| `qwen` | `qwen3.8-max` | dashscope.aliyuncs.com | 8792 | + 目录补丁 + message-id 前缀修正 |
| `hy` | `hy4` | tokenhub.tencentmaas.com | 8796 | 仓库编写的兼容目录 |
| `local` | `qwen3.8-27b-local` | 用户可配置（默认 127.0.0.1:8080） | 无 | 目录补丁、不走沙箱或 shim |
| `gpt-6-astra` | `gpt-6-astra` | OpenAI（ChatGPT 登录） | 无 | 不走 shim，订阅制，high 推理 |
| `gpt-6-astra-x` | `gpt-6-astra` | OpenAI（ChatGPT 登录） | 无 | 不走 shim，订阅制，xhigh 推理 |
| `gpt-6-astra-max` | `gpt-6-astra` | OpenAI（ChatGPT 登录） | 无 | 不走 shim，订阅制，max 推理 |
| `gpt-6-sol` | `gpt-6.1-sol` | OpenAI（ChatGPT 登录） | 无 | 不走 shim，订阅制，high 推理 |
| `gpt-6-sol-x` | `gpt-6.1-sol` | OpenAI（ChatGPT 登录） | 无 | 不走 shim，订阅制，xhigh 推理 |
| `gpt-6-sol-max` | `gpt-6.1-sol` | OpenAI（ChatGPT 登录） | 无 | 不走 shim，订阅制，max 推理 |
| `gpt-6-luna` | `gpt-6-luna` | OpenAI（ChatGPT 登录） | 无 | 不走 shim，订阅制，max 推理 |

九条 managed cloud 路由（`ds-flash`、`glm`、`glm-flash`、`kimi`、`mimo`、`mimo-fast`、`mimo-flash`、`qwen`、`hy`）均显式启用 `agent_message_fix`；其他、新增及环境变量单路由默认关闭。`local` 和 OpenAI 订阅 profiles 不走此 shim。该适配将 Codex 0.167.0 原生 Agent 间消息适配为标准 user 消息，保留内容顺序，以文本携带来源、接收者与元数据；原生 rollout 不变。适配假设实测 `agent_message` 的 `encrypted_content` 槽内是明文，无法解密真正的不透明密文；reasoning、工具参数和其他原生顶层 item 类型保持原样。实际 `agent_message` 中的未知或非法内容返回不含正文的 HTTP 400，避免转发残缺任务。仅在获授权后通过 `./scripts/sync-codex-agent.sh` 部署代码与路由，安装服务需要加载更新后的代码和路由。

路由开关 `native_agent_request_flatten` 与 `native_agent_response_restore` 默认关闭。Kimi 同时启用两者，仅针对实际广告的 `multi_agent_v1` / `collaboration`；MiMo Flash 仅启用响应恢复。映射限于当前请求，只给已广告原生函数调用补回缺失或 null 的 namespace，保留参数和 ID；其他 MCP/Code Mode 组与历史保持原样。存在有效映射的 Responses 成功响应要求 identity 编码及 SSE/JSON；SSE 逐事件转发，单事件与非流式 JSON 均限 8 MiB。Guardian 明确绕过两阶段。Kimi 请求 flatten 与映射仅使用顶层 `tools` 原生描述符。MiMo Flash 的 response-only 映射可读取当前请求顶层 `tools` 及直接位于 `input[type=additional_tools].tools` 容器中的原生描述符，完整请求字节保持不变。

云端凭据来自私有连接 JSON，由 shim 添加；`local` 不需要 key。七个 OpenAI profile 对应三个上游模型，共享 home 的 `auth.json`，`business` 保留 `~/.codex-agent/business/` 下的独立登录。

安装或更新：

```bash
# 安装 profiles、shim 脚本、路由表，并重新生成 model catalog
./scripts/sync-codex-agent.sh

# 可选但推荐：把 shim 交给 launchd 常驻
~/.codex-agent/bin/codex-auto-review-shim-service install
```

把 Agent 环境恢复到另一台 Mac 后，再运行一次 `install`。它会查找目标机器上的 Python 3.11+，重写
launchd plist，并重新加载已有服务。`restart` 只重启现有 plist，不会更新 Python 路径。
从更新后的仓库执行 `./scripts/sync-codex-agent.sh`，部署服务、连接 helper 和默认资源。缺少连接文件时使用不含云端凭据的项目默认值，启动前需初始化并填写云端 key。已有自定义文件保持原样。

仓库模板中的本机路径写作 `@HOME@`，由同步脚本在安装时替换为实际 home（Codex 只接受绝对路径）。

模型卡只承载模型差量（model、`model_provider`、reasoning effort、上下文/compact 窗口、`web_search`、
`model_catalog_json`）。十个第三方网关定义集中在 `codex-agent/model-providers.toml`，同步时作为带标记的块
写入共享 base，使恢复会话时可以解析历史 provider。`glm-flash`、`mimo-fast`、`mimo-flash` 因网关端口不同，
现在各有独立 provider ID。旧会话使用的共用 `glm` 或 `mimo` ID 无法识别其创建时的具体变体；
这两个旧 ID 保留普通 `glm` 和 `mimo` 路由。退役的 provider ID 也要在注册表中保留最后可用的路由；
删除 ID 会让记录该 ID 的历史会话无法恢复。政策（沙箱、审批、env 策略、`service_tier` 等）与 Codex 本体和
ChatGPT 桌面端写入的机器本地状态（`[projects.*]` trust、`[hooks.state]`、`[mcp_servers.*]`、`[plugins.*]`、
`[marketplaces.*]`、`[tui.*]`、`[desktop]` 以及 `notify` 等根键）都留在共享 home 的 base `config.toml` 里。
同步脚本只更新带标记的 provider 块；若相同 ID 已在块外定义，则报错而不覆盖。模型卡是纯产物，
同步时整文件覆盖。要给单个模型改设置，改仓库里那张卡再同步即可
（layering 让卡上的键压过 base）。

`model-catalogs/<id>.json` 仍是**生成型产物，不入仓库**。八个云端 profile 使用按字节校验的
[官方来源快照](codex-agent/catalog-sources/README.md)，保留完整源元数据和指令；每个只追加独立取得的
native guardian，云端会话不再使用 GPT donor。`glm-flash` 是用户明确授权的官方 `glm-5.3` 克隆，
仅修改三个身份字段、明确标注派生为 `glm-5.3-flash`，不切换 Turbo。Kimi 模型卡和 shim 逻辑 slug 为
`k3`，endpoint 管理的 URL/key/上游模型仍独立。Qwen 上下文 **983616**、压缩阈值 **737712**，
保留源里缺失的最大窗口；其它云端卡仍为 1048576/786432。这八个默认 effort 都是 **max**，官方支持
列表和默认等级完整保留。MiMo 快照未列 max（用户报告官方确认支持），Qwen 仅列 low/medium/xhigh；
生成器给出信息提示。模拟请求转发不证明厂商接受。Hy 独立使用上文的仓库兼容条目和 high effort，不改变这些官方来源。

DS/GLM/Kimi/Qwen guardian 使用 direct 且关闭 Lite；MiMo 保留 native Code Mode/Responses Lite 和
`additional_tools`。Native 0.162.1 的 `code_mode_host` 为 stable、默认 true，保持不显式设置，
隔离层原有 `code_mode=false` 也保留。必需的 Code Mode 需要已安装的 native host 和可用内核沙箱；
显式 host false 必须可见失败。MiMo 现有路由级 `json_schema` → `json_object` 降级同时作用于普通
会话与 guardian，会失去 schema 强制约束。只有 local 继续按能力选择 native direct-session donor，
不绑定模型 ID；GPT/business 不变。

生成器在空 home 下用 `codex debug models --bundled` 取得 native 来源，再在新的空 home 下对每个
完整输出执行 `codex -c model_catalog_json=... debug models`。嵌套 schema 由 native parser 判断。
映射缺失、来源/hash/卡片不一致或 native 拒绝会在 registry/卡片/catalog 替换前失败。Sync 备份所有
被替换的卡片/catalog 和 registry 字节，成对安装并校验安装字节。普通复制、替换、registry 或校验
失败会恢复原字节/模式/不存在状态；恢复本身失败则报错并保留备份。不保证跨文件原子可见性、
并发写协调、SIGKILL/断电恢复或恢复 I/O 失败后的可恢复性。后续 shim/service/business 部署不在此恢复块内。

定向验证（仅合成 endpoint）：

```bash
python3 -m unittest discover -s tests -p 'test_model_catalog_generation.py'
OFFICIAL_CATALOG_RUNTIME_TESTS=1 python3 -m unittest discover -s tests -p 'test_official_catalog_runtime.py'
```

Native 读写/收集和内核测试需要允许 Seatbelt 执行的父环境。官方 MiMo outer-boundary 用例还需
`AGENT_SANDBOX_KERNEL_TESTS=1`、`SRT_TEST_BIN=/absolute/path/to/srt`（已安装 0.0.79）。缺少前置条件
应标为失败/未验证，不使用更弱 fallback。[实施证据](docs/gateflow/official-provider-catalogs/implementation.md)
记录实际结果；真实厂商接受情况与 desktop/未来 runtime 兼容性另行验证。

### 手动恢复旧版 reasoning 历史

`repair-codex-reasoning-history.py` 保留用于明确手动执行的旧版 payload 恢复。launcher 不会调用它，
它也不能绕过 Codex 的 provider 不匹配边界。原会话只读时，请使用上文的原生续接流程。
此工具在指定 `--apply` 时会主动修改已保存的 reasoning 历史。

旧版 Responses 历史可能在 reasoning 记录的 `content` 数组里保存 `reasoning_text`，导致 OpenAI payload
校验报错 `Invalid 'input[n].content': array too long`（见[历史上游问题 #36551](https://github.com/openai/codex/issues/36551)）。
若要手动恢复这类旧版 payload，先退出所有正在使用该会话的 Codex 窗口，在 `~/.codex/sessions/` 中找到对应的 rollout，再执行：

```bash
python3 scripts/repair-codex-reasoning-history.py /path/to/rollout-<session-id>.jsonl
python3 scripts/repair-codex-reasoning-history.py /path/to/rollout-<session-id>.jsonl --apply
# 针对旧版 payload 的加密推理错误或 reasoning item ID 不存在：
python3 scripts/repair-codex-reasoning-history.py /path/to/rollout-<session-id>.jsonl --drop-reasoning-model k3 --drop-reasoning-model kimi-k3 --drop-reasoning-model mimo-v2.6-pro
python3 scripts/repair-codex-reasoning-history.py /path/to/rollout-<session-id>.jsonl --drop-reasoning-model k3 --drop-reasoning-model kimi-k3 --drop-reasoning-model mimo-v2.6-pro --apply
```

第一条命令只统计命中数。`--apply` 只将非空且全为 `reasoning_text` 的 reasoning `content` 改为 `null`，
替换前在原目录保存带时间戳的私有备份。第三方加密推理内容仍可能校验失败，其 item ID 也可能在 OpenAI
端点不存在。此时按来源模型使用 `--drop-reasoning-model`：只删除这些模型的 reasoning 记录，保留对话和工具历史。
被删记录中的内部推理及推理摘要不再出现在修复后的会话中，但仍保留在带时间戳的备份里。
参数精确匹配 `turn_context` 记录的逻辑模型名，而非 endpoint 的上游 wire 模型名或 profile 别名。
示例同时覆盖当前 Kimi `k3`、旧 Kimi `kimi-k3` 和 MiMo `mimo-v2.6-pro`；没有匹配项时工具会警告。
修复后的 rollout 和备份均收紧为仅所有者可访问（原文件允许所有者写入时为 `0600`）。
再次运行相同修复命令应显示零条命中。恢复后的线程能否使用所选 provider 仍由 Codex 决定；
删除 reasoning 并不能让原线程接受跨 provider 输入。
若工具报告不支持的 reasoning 内容或 JSONL 损坏，会保持原文件不变；需单独检查报错行。需要回滚时，
先再次退出会话，再把命令输出的 `rollout-*.jsonl.backup-<timestamp>` 文件复制覆盖原 rollout。
确认手动恢复结果前保留备份。

### 切换 sandbox 模式

共享 home 的 base `config.toml` 定义默认沙箱：`"workspace-write"`——写入限制在 workspace，
`[sandbox_workspace_write] network_access = true` 保持网络放开（需要 shim 处于运行状态）。单个模型要例外，
在它的模型卡里写 `sandbox_mode` 覆盖 base——`local` 就是这样拿到 `"danger-full-access"`（无沙箱，
只在终端交互使用，不作为子 Agent 派发）。改卡后重跑 `./scripts/sync-codex-agent.sh`。

`local` 在共享 provider 注册表中直连 `local.codex` 指定的服务（默认 `http://127.0.0.1:8080/v1`）。

## 使用方式

### Gateflow

`gateflow` 用于单个 work unit：feature、issue、bug fix、migration、refactor、schema/public contract change 或
architecture-sensitive task。Gateflow 只定义 gates：preflight、goal confirmation、最小必要计划与适用计划审核、实现/验证、
一轮完整代码审核、必要修复及受影响面复审、draft PR 交付核对和 final closeout。

单独使用 Gateflow 示例：

```text
按照 $gateflow 开发 <work-unit>。
可选设计依据：docs/host/design.md。
先做 preflight 和 goal confirmation；用户确认目标、非目标和边界后，按 Gate Order 推进到 final closeout。
严格遵循 AGENTS.md 的约束。
```

Gateflow + `tmux-agents` 示例：

```text
按照 $gateflow 开发 <work-unit>。
$tmux-agents 路由 Agents，CodexAgent-GPT-6-Astra 负责 plan / implement / fix，CodexAgent-MiMo / ClaudeAgent-DS-Flash 并行完成所需独立审核和必要受影响面复审。
每次发送前重新 discovery pane，clear 新任务 session，避免裸 #数字。
严格遵循 AGENTS.md 的约束。
```

Gateflow + `sub-agents` 示例：

```text
按照 $gateflow 开发 <work-unit>。
$sub-agents 通过 runner 子进程派发：Codex gpt-6-astra 负责 plan / implement / fix，Codex mimo / Claude ds-flash 并行完成所需独立审核和必要受影响面复审。
所有调用显式传入 workspace 绝对路径，并使用独立 output / stderr 文件；总控检查结构化结果后自行裁决。
严格遵循 AGENTS.md 的约束。
```

### Phaseflow

当项目有设计真源文档和实施总控文档时，使用 `phaseflow`。Phaseflow 是项目分步总控：读取当前 `phase = work unit`，
和用户完成 preflight / goal confirmation，读取 Gateflow 的 `Gate Order`，亲自核对简单计划和 PR 交付，派发 Agent 做具体任务与
适用审核，裁决结果，更新 `control_doc`，并 reconcile residual risks。

单独使用 Phaseflow 示例：

未指定派发协议时，Phaseflow 默认使用 `sub-agents`。只有显式指定 `$tmux-agents` 时才通过已有 tmux pane 派发。

```text
按照 $phaseflow 推进，设计真源在 docs/host/design.md，总控文档是 docs/host/issues-implementation-control.md。
先读取 control_doc 识别当前 phase/work unit，再读取 design_doc。
总控 Agent 先完成 preflight 和 goal confirmation；用户确认后，按 Gateflow 的 Gate Order 核对简单计划和 PR 交付，派发具体任务与适用独立审核。
每个 gate 返回后更新 control_doc、记录 artifact / finding 裁决 / residual risk。
final closeout 后说明用户 merge PR、拉取目标 base branch，并从 control_doc 的 next entry point 继续下一轮。
严格遵循 AGENTS.md 的约束。
```

Phaseflow + `tmux-agents` 示例：

```text
按照 $phaseflow 推进，设计真源在 docs/host/design.md，总控文档是 docs/host/issues-implementation-control.md。
$tmux-agents 路由 Agents，CodexAgent-MiMo / ClaudeAgent-DS-Flash 并行完成所需独立审核和必要受影响面复审，CodexAgent-GPT-6-Astra 负责 plan / implement / fix。
总控 Agent 先做 preflight 和 goal confirmation；确认后按 Gateflow 的 Gate Order 推进，亲自核对简单计划和 PR 交付。
每个 Agent 返回后，总控读取 artifact、裁决 finding、更新 control_doc、收集 residual risk、关闭已解决 risk。
final closeout 后说明用户 merge PR、拉取目标 base branch，并从 control_doc 的 next entry point 继续下一轮。
严格遵循 AGENTS.md 的约束。
```

Phaseflow + `sub-agents` 示例：

```text
按照 $phaseflow 推进，设计真源在 docs/host/design.md，总控文档是 docs/host/issues-implementation-control.md。
$sub-agents 通过 runner 子进程派发，Codex mimo / Claude ds-flash 并行完成所需独立审核和必要受影响面复审，Codex gpt-6-astra 负责 plan / implement / fix。
总控按 Gateflow 的 Gate Order 推进，亲自核对简单计划和 PR 交付，检查每个子进程的退出状态和结构化输出，并更新 control_doc。
严格遵循 AGENTS.md 的约束。
```

### Planreview

重要决策或显式审核请求使用 `planreview`，判断 plan 是否足以指导正确实现、切片和机制是否必要、是否解决已证实的根因，
不替实现者预写局部代码细节。

Codex:

```text
$planreview docs/path/to/plan.md
```

Claude Code:

```text
/planreview docs/path/to/plan.md
```

预期输出是 durable review artifact，通常写到 `docs/reviews/` 或项目指定的 review 目录。

### Deepreview

使用 `deepreview` 做严格 code review。

review 当前分支相对 `main` 的改动：

```text
$deepreview
```

等价显式写法：

```text
$deepreview --base main
```

review 指定 PR：

```text
$deepreview --pr 123
```

review 整个仓库：

```text
$deepreview --all
```

Claude Code 使用 `/deepreview`，参数相同。

预期输出是 durable review artifact，包含基于证据的 findings、状态追踪和 residual risk 说明。

### Tmux Agents

当需要通过 tmux pane 向已经启动的 CLI Agent 发送任务时，使用 `tmux-agents`。它只定义通信：CLI 类型、`/skill` vs `$skill`、
pane discovery、clear/session 规则、`tmux-cli send/wait_idle/capture` 和发送安全规则。它不分配角色。

Codex:

```text
使用 $tmux-agents 初始化多 Agent 通信约定。
```

Claude Code:

```text
使用 /tmux-agents 初始化多 Agent 通信约定。
```

`tmux-agents` 使用以下基本命令：

```bash
tmux-cli status
tmux-cli send "<prompt>" --pane=<full-pane-id>
tmux-cli wait_idle --pane=<full-pane-id> --idle-time=3 --timeout=<seconds>
tmux-cli capture --pane=<full-pane-id>
```

Agent-to-agent chat 使用 `tmux-cli send` + `wait_idle` + `capture`。`tmux-cli execute` 只用于需要 exit code 的 shell command。

### Sub Agents

总控需要通过已安装的 runner 启动外部 Claude Code 或 Codex 子进程时，使用 `sub-agents`。该 skill 说明独立 prompt
上下文、显式 workspace、托管并行执行、最终答复收取及可选检查/隔离；具体任务的验证，以及在现有用户/项目授权与指定路由下
是否继续或重试，均由调用方决定。runner 不自动重试或切换 provider。

Codex:

```text
使用 $sub-agents 通过 runner 子进程派发并裁决当前子任务。
```

Claude Code:

```text
使用 /sub-agents 通过 runner 子进程派发并裁决当前子任务。
```

底层命令为：

```bash
claude-agent-run --provider <provider> --cwd <absolute-workspace> ...
codex-agent-run --provider <provider> --cwd <absolute-workspace> ...
```

写入范围不重叠的独立任务可以并发。runner 收集执行证据，总控使用最终答复，按任务要求核对未解决问题和产物。

## 仓库结构

```text
skills/
  gateflow/
    SKILL.md
    agents/openai.yaml
  phaseflow/
    SKILL.md
    agents/openai.yaml
  planreview/
    SKILL.md
    agents/openai.yaml
  deepreview/
    SKILL.md
    agents/openai.yaml
  tmux-agents/
    SKILL.md
    agents/openai.yaml
  sub-agents/
    SKILL.md
    agents/openai.yaml
codex-agent/
  model-providers.toml
  profiles/
    ds-flash/config.toml
    glm/config.toml
    glm-flash/config.toml
    hy/config.toml
    kimi/config.toml
    mimo/config.toml
    mimo-fast/config.toml
    mimo-flash/config.toml
    qwen/config.toml
    local/config.toml
    gpt-6-astra/config.toml
    gpt-6-astra-x/config.toml
    gpt-6-astra-max/config.toml
    gpt-6-sol/config.toml
    gpt-6-sol-x/config.toml
    gpt-6-sol-max/config.toml
    gpt-6-luna/config.toml
  bin/
    codex-auto-review-shim
    codex-auto-review-shim-service
  shim-routes.json
install.sh
config/
  endpoints.example.json
scripts/
  agent-endpoint.py
  validate-skill.py
  agent-tools.zsh
  claude-agent-run
  codex-agent-run
  compose-codex-app-config.py
  sub-agent-preflight
  sync-codex-providers.py
  patch-codex-model-catalog.py
  repair-codex-reasoning-history.py
  sync-codex-model-defaults.py
  sync-agent-tools.sh
  sync-codex-agent.sh
  validate-skills.sh
  sync-skills.sh
tests/
  test_install_endpoints.py
  test_codex_model_defaults.py
  test_provider_registry.py
  test_repair_codex_reasoning_history.py
```

## 维护流程

只编辑本仓库中的真源文件：

```text
skills/<skill-name>/SKILL.md
skills/<skill-name>/agents/openai.yaml
install.sh
config/endpoints.example.json
scripts/agent-endpoint.py
scripts/validate-skill.py
scripts/agent-tools.zsh
scripts/claude-agent-run
scripts/agent-run-result.py
scripts/codex-agent-run
scripts/compose-codex-app-config.py
codex-agent/model-providers.toml
codex-agent/profiles/<agent-id>/config.toml
codex-agent/bin/
codex-agent/shim-routes.json
scripts/patch-codex-model-catalog.py
scripts/repair-codex-reasoning-history.py
scripts/sync-codex-model-defaults.py
scripts/sync-codex-providers.py
tests/test_codex_model_defaults.py
tests/test_provider_registry.py
tests/test_install_endpoints.py
tests/test_repair_codex_reasoning_history.py
```

校验全部 skills：

```bash
./scripts/validate-skills.sh
```

检查 provider 注册同步与桌面端迁移路径：

```bash
python3 -m unittest discover -s tests
```

同步到本地 Codex / Claude homes：

```bash
./scripts/sync-skills.sh
```

同步 Agent 启动函数和子 Agent runner：

```bash
./scripts/sync-agent-tools.sh
```

同步 Codex Agent profiles、shim 脚本与路由表：

```bash
./scripts/sync-codex-agent.sh
```

skill 同步脚本会先 validate，再把每个 skill 复制到已存在的本地目标目录。agent-tools 同步脚本以 `600` 权限把
启动函数安装到 `~/.config/zsh/agent-tools.zsh`，并以 `755` 权限把 runner 安装到 `~/.local/bin`。codex-agent
同步脚本只更新共享 base `config.toml` 中带标记的 provider 块，把模型卡整文件写入共享 home
（`~/.codex/<agent-id>.config.toml`），安装 shim 脚本与路由表，并重新生成不入仓库的 `model-catalogs/`。
这些脚本都不会 push、
publish、create PR，也不会修改远程仓库。

## 说明

- `gateflow` 定义单个 work unit 的 gates。
- `phaseflow` 核对简单计划和 PR 交付；具体 plan / implementation / fix 及适用独立 review 交给 Agent 完成。
- `planreview` 和 `deepreview` 是 review skills。它们应该输出 durable artifacts，而不是只在聊天里给结论。
- 只有在通过 tmux 路由多个 CLI Agent 时才需要 `tmux-agents`。
- 总控通过 runner 子进程启动外部子 Agent 时使用 `sub-agents`。
